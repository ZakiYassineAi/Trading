import React, { useState } from 'react';
import {
  BarChart3,
  TrendingUp,
  Wallet,
  BookOpen,
  AlertTriangle,
  Settings,
  ChevronLeft,
  ChevronRight,
  Activity,
  PieChart,
  Target,
  DollarSign
} from 'lucide-react';

interface SidebarProps {
  activeSection?: string;
  onSectionChange?: (section: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeSection = 'dashboard', onSectionChange }) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const menuItems = [
    {
      id: 'dashboard',
      label: 'لوحة التحكم',
      icon: BarChart3,
      description: 'نظرة عامة على الأداء'
    },
    {
      id: 'backtest',
      label: 'اختبار الاستراتيجيات',
      icon: TrendingUp,
      description: 'تحليل الأداء التاريخي'
    },
    {
      id: 'portfolio',
      label: 'المحفظة الوهمية',
      icon: Wallet,
      description: 'إدارة المحفظة الاستثمارية'
    },
    {
      id: 'alerts',
      label: 'التنبيهات',
      icon: AlertTriangle,
      description: 'تنبيهات السوق والأسعار'
    },
    {
      id: 'education',
      label: 'التعليم',
      icon: BookOpen,
      description: 'وحدة DeFi التعليمية'
    },
    {
      id: 'analytics',
      label: 'التحليلات المتقدمة',
      icon: Activity,
      description: 'تحليلات عميقة للسوق'
    },
    {
      id: 'performance',
      label: 'مؤشرات الأداء',
      icon: PieChart,
      description: 'قياس أداء الاستراتيجيات'
    },
    {
      id: 'risk',
      label: 'إدارة المخاطر',
      icon: Target,
      description: 'تقييم وإدارة المخاطر'
    }
  ];

  const handleItemClick = (itemId: string) => {
    if (onSectionChange) {
      onSectionChange(itemId);
    }
  };

  return (
    <aside className={`bg-gray-900 border-r border-gray-800 transition-all duration-300 flex flex-col ${
      isCollapsed ? 'w-16' : 'w-64'
    }`}>
      {/* Collapse Button */}
      <div className="p-4 border-b border-gray-800">
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="w-full flex items-center justify-center p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg transition-all"
        >
          {isCollapsed ? (
            <ChevronRight className="h-5 w-5" />
          ) : (
            <>
              <ChevronLeft className="h-5 w-5 ml-2" />
              <span className="text-sm font-medium">طي القائمة</span>
            </>
          )}
        </button>
      </div>

      {/* Navigation Menu */}
      <nav className="flex-1 p-4 space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeSection === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => handleItemClick(item.id)}
              className={`w-full flex items-center p-3 rounded-lg transition-all group ${
                isActive
                  ? 'bg-gradient-to-r from-blue-600 to-green-600 text-white'
                  : 'text-gray-300 hover:text-white hover:bg-gray-800'
              }`}
              title={isCollapsed ? item.label : ''}
            >
              <Icon className={`h-5 w-5 ${isCollapsed ? '' : 'ml-3'}`} />
              
              {!isCollapsed && (
                <div className="flex-1 text-right">
                  <div className="font-medium">{item.label}</div>
                  <div className={`text-xs mt-1 ${
                    isActive ? 'text-blue-100' : 'text-gray-500 group-hover:text-gray-400'
                  }`}>
                    {item.description}
                  </div>
                </div>
              )}

              {/* Active indicator */}
              {isActive && !isCollapsed && (
                <div className="w-1 h-6 bg-white rounded-full opacity-80" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer Section */}
      {!isCollapsed && (
        <div className="p-4 border-t border-gray-800">
          <div className="bg-gray-800 rounded-lg p-4">
            <div className="flex items-center mb-2">
              <DollarSign className="h-5 w-5 text-green-400 ml-2" />
              <span className="text-sm font-medium text-white">رصيد المحفظة الوهمية</span>
            </div>
            <div className="text-2xl font-bold text-green-400 mb-1">
              $10,000.00
            </div>
            <div className="text-xs text-gray-400">
              <span className="text-green-400">+2.5%</span> منذ بداية الشهر
            </div>
          </div>
        </div>
      )}

      {/* Settings */}
      <div className="p-4 border-t border-gray-800">
        <button
          className="w-full flex items-center p-3 text-gray-300 hover:text-white hover:bg-gray-800 rounded-lg transition-all"
          title={isCollapsed ? 'الإعدادات' : ''}
        >
          <Settings className={`h-5 w-5 ${isCollapsed ? '' : 'ml-3'}`} />
          {!isCollapsed && (
            <span className="font-medium">الإعدادات</span>
          )}
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;