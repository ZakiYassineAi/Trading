import React from 'react';
import { Bell, Settings, User, TrendingUp } from 'lucide-react';

interface HeaderProps {
  currentUser?: {
    name: string;
    avatar?: string;
  };
}

const Header: React.FC<HeaderProps> = ({ currentUser }) => {
  return (
    <header className="bg-gray-900 border-b border-gray-800 px-6 py-4">
      <div className="flex items-center justify-between">
        {/* Logo and Title */}
        <div className="flex items-center space-x-3">
          <div className="bg-gradient-to-r from-blue-500 to-green-500 p-2 rounded-lg">
            <TrendingUp className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">منصة التداول الكمي</h1>
            <p className="text-sm text-gray-400">تحليل وتقييم استراتيجيات التداول</p>
          </div>
        </div>

        {/* Navigation Links */}
        <nav className="hidden md:flex items-center space-x-6 rtl:space-x-reverse">
          <a href="#dashboard" className="text-gray-300 hover:text-blue-400 transition-colors font-medium">
            لوحة التحكم
          </a>
          <a href="#backtest" className="text-gray-300 hover:text-blue-400 transition-colors font-medium">
            اختبار الاستراتيجيات
          </a>
          <a href="#portfolio" className="text-gray-300 hover:text-blue-400 transition-colors font-medium">
            المحفظة الوهمية
          </a>
          <a href="#education" className="text-gray-300 hover:text-blue-400 transition-colors font-medium">
            التعليم
          </a>
        </nav>

        {/* User Actions */}
        <div className="flex items-center space-x-4 rtl:space-x-reverse">
          {/* Notifications */}
          <button className="relative p-2 text-gray-400 hover:text-white transition-colors">
            <Bell className="h-5 w-5" />
            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
              3
            </span>
          </button>

          {/* Settings */}
          <button className="p-2 text-gray-400 hover:text-white transition-colors">
            <Settings className="h-5 w-5" />
          </button>

          {/* User Profile */}
          <div className="flex items-center space-x-3 rtl:space-x-reverse">
            {currentUser ? (
              <>
                <span className="text-gray-300 text-sm hidden sm:block">
                  {currentUser.name}
                </span>
                {currentUser.avatar ? (
                  <img
                    src={currentUser.avatar}
                    alt="User Avatar"
                    className="h-8 w-8 rounded-full border-2 border-gray-600"
                  />
                ) : (
                  <div className="h-8 w-8 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center">
                    <User className="h-4 w-4 text-white" />
                  </div>
                )}
              </>
            ) : (
              <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors">
                تسجيل الدخول
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      <nav className="md:hidden mt-4 pt-4 border-t border-gray-800">
        <div className="flex space-x-4 rtl:space-x-reverse overflow-x-auto">
          <a href="#dashboard" className="text-gray-300 hover:text-blue-400 whitespace-nowrap">
            لوحة التحكم
          </a>
          <a href="#backtest" className="text-gray-300 hover:text-blue-400 whitespace-nowrap">
            اختبار الاستراتيجيات
          </a>
          <a href="#portfolio" className="text-gray-300 hover:text-blue-400 whitespace-nowrap">
            المحفظة الوهمية
          </a>
          <a href="#education" className="text-gray-300 hover:text-blue-400 whitespace-nowrap">
            التعليم
          </a>
        </div>
      </nav>
    </header>
  );
};

export default Header;