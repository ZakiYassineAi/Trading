import React from 'react';
import { Github, Mail, Globe, Shield, BookOpen, AlertTriangle } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 border-t border-gray-800 mt-auto">
      <div className="px-6 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* About Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white mb-4">حول المنصة</h3>
            <p className="text-gray-400 text-sm leading-relaxed">
              منصة تعليمية متقدمة لتحليل وتقييم استراتيجيات التداول الكمي في بيئة آمنة وخالية من المخاطر المالية الحقيقية.
            </p>
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <Shield className="h-4 w-4 text-green-400" />
              <span className="text-sm text-green-400 font-medium">تداول ورقي آمن 100%</span>
            </div>
          </div>

          {/* Features */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white mb-4">الميزات الرئيسية</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li className="flex items-center">
                <div className="w-2 h-2 bg-blue-500 rounded-full ml-2"></div>
                محرك باك-تست متقدم
              </li>
              <li className="flex items-center">
                <div className="w-2 h-2 bg-green-500 rounded-full ml-2"></div>
                تحليلات السوق المباشرة
              </li>
              <li className="flex items-center">
                <div className="w-2 h-2 bg-purple-500 rounded-full ml-2"></div>
                نظام تنبيهات ذكي
              </li>
              <li className="flex items-center">
                <div className="w-2 h-2 bg-orange-500 rounded-full ml-2"></div>
                وحدة DeFi تعليمية
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white mb-4">الموارد التعليمية</h3>
            <ul className="space-y-2">
              <li>
                <a href="#docs" className="text-gray-400 hover:text-blue-400 text-sm transition-colors flex items-center">
                  <BookOpen className="h-4 w-4 ml-2" />
                  دليل المستخدم
                </a>
              </li>
              <li>
                <a href="#tutorials" className="text-gray-400 hover:text-blue-400 text-sm transition-colors flex items-center">
                  <Globe className="h-4 w-4 ml-2" />
                  دروس تفاعلية
                </a>
              </li>
              <li>
                <a href="#api" className="text-gray-400 hover:text-blue-400 text-sm transition-colors flex items-center">
                  <Github className="h-4 w-4 ml-2" />
                  مستندات API
                </a>
              </li>
              <li>
                <a href="#support" className="text-gray-400 hover:text-blue-400 text-sm transition-colors flex items-center">
                  <Mail className="h-4 w-4 ml-2" />
                  الدعم الفني
                </a>
              </li>
            </ul>
          </div>

          {/* Disclaimer */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white mb-4">إخلاء المسؤولية</h3>
            <div className="bg-yellow-900/20 border border-yellow-600/30 rounded-lg p-3">
              <div className="flex items-start">
                <AlertTriangle className="h-4 w-4 text-yellow-400 mt-0.5 ml-2 flex-shrink-0" />
                <p className="text-xs text-yellow-200 leading-relaxed">
                  هذه منصة تعليمية لأغراض التعلم فقط. جميع العمليات هي تداول ورقي ولا تتضمن أموالاً حقيقية. النتائج الماضية لا تضمن الأداء المستقبلي.
                </p>
              </div>
            </div>
            <div className="text-xs text-gray-500">
              آخر تحديث: {new Date().toLocaleDateString('ar-SA')}
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-8 pt-6 border-t border-gray-800 flex flex-col md:flex-row justify-between items-center">
          <div className="text-sm text-gray-400 mb-4 md:mb-0">
            © {currentYear} منصة التداول الكمي. جميع الحقوق محفوظة.
          </div>
          
          <div className="flex items-center space-x-6 rtl:space-x-reverse">
            <a href="#privacy" className="text-sm text-gray-400 hover:text-white transition-colors">
              سياسة الخصوصية
            </a>
            <a href="#terms" className="text-sm text-gray-400 hover:text-white transition-colors">
              شروط الاستخدام
            </a>
            <a href="#about" className="text-sm text-gray-400 hover:text-white transition-colors">
              حول المطورين
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;