import React, { useState, useEffect } from 'react';
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  PieChart,
  DollarSign,
  Eye,
  EyeOff,
  RefreshCw,
  Download,
  Upload,
  History,
  Target,
  AlertTriangle,
  CheckCircle
} from 'lucide-react';

interface Asset {
  symbol: string;
  name: string;
  balance: number;
  value: number;
  price: number;
  change24h: number;
  allocation: number;
}

interface Transaction {
  id: string;
  type: 'buy' | 'sell' | 'deposit' | 'withdrawal';
  symbol: string;
  amount: number;
  price: number;
  value: number;
  fee: number;
  timestamp: Date;
  status: 'completed' | 'pending' | 'failed';
}

const PortfolioManager: React.FC = () => {
  const [isBalanceVisible, setIsBalanceVisible] = useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState('24h');
  const [assets, setAssets] = useState<Asset[]>([
    {
      symbol: 'BTC',
      name: 'Bitcoin',
      balance: 0.5643,
      value: 37923.45,
      price: 67234.56,
      change24h: 2.34,
      allocation: 65.2
    },
    {
      symbol: 'ETH',
      name: 'Ethereum', 
      balance: 8.2341,
      value: 28456.78,
      price: 3456.78,
      change24h: -1.12,
      allocation: 24.6
    },
    {
      symbol: 'BNB',
      name: 'BNB',
      balance: 45.6782,
      value: 14267.89,
      price: 312.45,
      change24h: 0.89,
      allocation: 7.8
    },
    {
      symbol: 'ADA',
      name: 'Cardano',
      balance: 5432.1,
      value: 2480.12,
      price: 0.4567,
      change24h: 3.45,
      allocation: 2.4
    }
  ]);

  const [transactions, setTransactions] = useState<Transaction[]>([
    {
      id: '1',
      type: 'buy',
      symbol: 'BTC',
      amount: 0.1234,
      price: 67000.00,
      value: 8267.80,
      fee: 16.54,
      timestamp: new Date(Date.now() - 10 * 60000),
      status: 'completed'
    },
    {
      id: '2',
      type: 'sell',
      symbol: 'ETH',
      amount: 2.567,
      price: 3450.00,
      value: 8856.15,
      fee: 17.71,
      timestamp: new Date(Date.now() - 45 * 60000),
      status: 'completed'
    },
    {
      id: '3',
      type: 'deposit',
      symbol: 'USDT',
      amount: 10000.00,
      price: 1.00,
      value: 10000.00,
      fee: 0,
      timestamp: new Date(Date.now() - 2 * 60 * 60000),
      status: 'completed'
    }
  ]);

  const totalValue = assets.reduce((sum, asset) => sum + asset.value, 0);
  const totalChange24h = assets.reduce((sum, asset) => sum + (asset.value * asset.change24h / 100), 0);
  const totalChangePercent = (totalChange24h / totalValue) * 100;

  const portfolioStats = {
    totalValue,
    totalChange24h,
    totalChangePercent,
    totalAssets: assets.length,
    activePositions: assets.filter(a => a.balance > 0).length,
    bestPerformer: assets.reduce((best, current) => 
      current.change24h > best.change24h ? current : best, assets[0]),
    worstPerformer: assets.reduce((worst, current) => 
      current.change24h < worst.change24h ? current : worst, assets[0])
  };

  useEffect(() => {
    // Simulate real-time price updates
    const interval = setInterval(() => {
      setAssets(prev => prev.map(asset => {
        const priceChange = (Math.random() - 0.5) * 0.02; // ±1% change
        const newPrice = asset.price * (1 + priceChange);
        const newValue = asset.balance * newPrice;
        const newChange24h = asset.change24h + (Math.random() - 0.5) * 0.5;
        
        return {
          ...asset,
          price: newPrice,
          value: newValue,
          change24h: newChange24h
        };
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const formatCurrency = (value: number) => `$${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  const formatCrypto = (value: number, symbol: string) => `${value.toLocaleString(undefined, { minimumFractionDigits: 4, maximumFractionDigits: 8 })} ${symbol}`;

  const getTransactionIcon = (type: Transaction['type']) => {
    switch (type) {
      case 'buy': return <TrendingUp className="h-4 w-4 text-green-400" />;
      case 'sell': return <TrendingDown className="h-4 w-4 text-red-400" />;
      case 'deposit': return <Download className="h-4 w-4 text-blue-400" />;
      case 'withdrawal': return <Upload className="h-4 w-4 text-orange-400" />;
    }
  };

  const getTransactionLabel = (type: Transaction['type']) => {
    switch (type) {
      case 'buy': return 'شراء';
      case 'sell': return 'بيع';
      case 'deposit': return 'إيداع';
      case 'withdrawal': return 'سحب';
    }
  };

  const getStatusIcon = (status: Transaction['status']) => {
    switch (status) {
      case 'completed': return <CheckCircle className="h-4 w-4 text-green-400" />;
      case 'pending': return <RefreshCw className="h-4 w-4 text-yellow-400 animate-spin" />;
      case 'failed': return <AlertTriangle className="h-4 w-4 text-red-400" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Portfolio Overview */}
      <div className="bg-gradient-to-r from-gray-800 to-gray-900 rounded-xl p-6 border border-gray-700">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Wallet className="h-6 w-6 text-green-400 ml-3" />
            <h2 className="text-2xl font-bold text-white">إجمالي المحفظة</h2>
          </div>
          
          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            <button
              onClick={() => setIsBalanceVisible(!isBalanceVisible)}
              className="p-2 hover:bg-gray-700 rounded transition-colors"
            >
              {isBalanceVisible ? (
                <Eye className="h-5 w-5 text-gray-400" />
              ) : (
                <EyeOff className="h-5 w-5 text-gray-400" />
              )}
            </button>
            <button className="p-2 hover:bg-gray-700 rounded transition-colors">
              <RefreshCw className="h-5 w-5 text-gray-400" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Total Value */}
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-2">
              {isBalanceVisible ? formatCurrency(portfolioStats.totalValue) : '••••••'}
            </div>
            <div className="text-gray-400 text-sm">إجمالي القيمة</div>
            <div className={`flex items-center justify-center text-sm mt-2 ${
              portfolioStats.totalChangePercent >= 0 ? 'text-green-400' : 'text-red-400'
            }`}>
              {portfolioStats.totalChangePercent >= 0 ? (
                <TrendingUp className="h-4 w-4 ml-1" />
              ) : (
                <TrendingDown className="h-4 w-4 ml-1" />
              )}
              {Math.abs(portfolioStats.totalChangePercent).toFixed(2)}%
              <span className="mr-2">({Math.abs(portfolioStats.totalChange24h).toFixed(2)})</span>
            </div>
          </div>

          {/* Best Performer */}
          <div className="text-center">
            <div className="text-xl font-bold text-green-400 mb-2">
              {portfolioStats.bestPerformer.symbol}
            </div>
            <div className="text-gray-400 text-sm">أفضل أداء</div>
            <div className="text-green-400 text-sm mt-2">
              +{portfolioStats.bestPerformer.change24h.toFixed(2)}%
            </div>
          </div>

          {/* Worst Performer */}
          <div className="text-center">
            <div className="text-xl font-bold text-red-400 mb-2">
              {portfolioStats.worstPerformer.symbol}
            </div>
            <div className="text-gray-400 text-sm">أضعف أداء</div>
            <div className="text-red-400 text-sm mt-2">
              {portfolioStats.worstPerformer.change24h.toFixed(2)}%
            </div>
          </div>

          {/* Active Assets */}
          <div className="text-center">
            <div className="text-xl font-bold text-blue-400 mb-2">
              {portfolioStats.activePositions}
            </div>
            <div className="text-gray-400 text-sm">الأصول النشطة</div>
            <div className="text-blue-400 text-sm mt-2">
              من {portfolioStats.totalAssets} إجمالي
            </div>
          </div>
        </div>
      </div>

      {/* Assets Allocation & Holdings */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Portfolio Allocation Pie Chart */}
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <h3 className="text-xl font-bold text-white mb-4 flex items-center">
            <PieChart className="h-5 w-5 ml-2" />
            توزيع المحفظة
          </h3>
          
          {/* Simple pie chart representation */}
          <div className="relative w-48 h-48 mx-auto mb-4">
            <svg viewBox="0 0 200 200" className="w-full h-full">
              {assets.map((asset, index) => {
                const startAngle = assets.slice(0, index).reduce((sum, a) => sum + (a.allocation * 3.6), 0);
                const endAngle = startAngle + (asset.allocation * 3.6);
                const x1 = 100 + 80 * Math.cos((startAngle - 90) * Math.PI / 180);
                const y1 = 100 + 80 * Math.sin((startAngle - 90) * Math.PI / 180);
                const x2 = 100 + 80 * Math.cos((endAngle - 90) * Math.PI / 180);
                const y2 = 100 + 80 * Math.sin((endAngle - 90) * Math.PI / 180);
                const largeArcFlag = asset.allocation > 50 ? 1 : 0;
                
                const colors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444'];
                
                return (
                  <path
                    key={asset.symbol}
                    d={`M 100 100 L ${x1} ${y1} A 80 80 0 ${largeArcFlag} 1 ${x2} ${y2} Z`}
                    fill={colors[index % colors.length]}
                    opacity="0.8"
                  />
                );
              })}
            </svg>
          </div>
          
          {/* Legend */}
          <div className="space-y-2">
            {assets.map((asset, index) => {
              const colors = ['bg-blue-500', 'bg-green-500', 'bg-yellow-500', 'bg-red-500'];
              return (
                <div key={asset.symbol} className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className={`w-3 h-3 rounded-full ${colors[index % colors.length]} ml-2`} />
                    <span className="text-gray-300 text-sm">{asset.symbol}</span>
                  </div>
                  <span className="text-white text-sm font-medium">{asset.allocation.toFixed(1)}%</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Holdings List */}
        <div className="lg:col-span-2 bg-gray-800 rounded-xl p-6 border border-gray-700">
          <h3 className="text-xl font-bold text-white mb-4 flex items-center">
            <Target className="h-5 w-5 ml-2" />
            مقتنيات المحفظة
          </h3>
          
          {/* Headers */}
          <div className="grid grid-cols-5 gap-4 mb-4 text-sm text-gray-400 font-medium">
            <div>الأصل</div>
            <div className="text-center">الرصيد</div>
            <div className="text-center">السعر</div>
            <div className="text-center">القيمة</div>
            <div className="text-center">24س %</div>
          </div>
          
          {/* Asset Rows */}
          <div className="space-y-2">
            {assets.map((asset) => (
              <div 
                key={asset.symbol}
                className="grid grid-cols-5 gap-4 p-3 rounded-lg hover:bg-gray-700/50 transition-colors"
              >
                {/* Asset Info */}
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white text-sm font-bold ml-3">
                    {asset.symbol[0]}
                  </div>
                  <div>
                    <div className="text-white font-medium">{asset.symbol}</div>
                    <div className="text-gray-400 text-xs">{asset.name}</div>
                  </div>
                </div>
                
                {/* Balance */}
                <div className="text-center">
                  <div className="text-white">{formatCrypto(asset.balance, asset.symbol)}</div>
                </div>
                
                {/* Price */}
                <div className="text-center">
                  <div className="text-white">{formatCurrency(asset.price)}</div>
                </div>
                
                {/* Value */}
                <div className="text-center">
                  <div className="text-white font-medium">{formatCurrency(asset.value)}</div>
                  <div className="text-gray-400 text-xs">{asset.allocation.toFixed(1)}%</div>
                </div>
                
                {/* 24h Change */}
                <div className="text-center">
                  <div className={`flex items-center justify-center text-sm ${
                    asset.change24h >= 0 ? 'text-green-400' : 'text-red-400'
                  }`}>
                    {asset.change24h >= 0 ? (
                      <TrendingUp className="h-3 w-3 ml-1" />
                    ) : (
                      <TrendingDown className="h-3 w-3 ml-1" />
                    )}
                    {Math.abs(asset.change24h).toFixed(2)}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-white flex items-center">
            <History className="h-5 w-5 ml-2" />
            آخر المعاملات
          </h3>
          
          <div className="flex space-x-2 rtl:space-x-reverse">
            {['24h', '7d', '30d', 'الكل'].map(period => (
              <button
                key={period}
                onClick={() => setSelectedPeriod(period)}
                className={`px-3 py-1 rounded text-sm transition-colors ${
                  selectedPeriod === period
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-400 hover:text-white hover:bg-gray-700'
                }`}
              >
                {period}
              </button>
            ))}
          </div>
        </div>
        
        {/* Transaction Headers */}
        <div className="grid grid-cols-6 gap-4 mb-4 text-sm text-gray-400 font-medium">
          <div>النوع</div>
          <div>الأصل</div>
          <div className="text-center">الكمية</div>
          <div className="text-center">السعر</div>
          <div className="text-center">القيمة</div>
          <div className="text-center">الحالة</div>
        </div>
        
        {/* Transaction List */}
        <div className="space-y-2 max-h-80 overflow-y-auto">
          {transactions.map((tx) => (
            <div 
              key={tx.id}
              className="grid grid-cols-6 gap-4 p-3 rounded-lg hover:bg-gray-700/50 transition-colors"
            >
              {/* Type */}
              <div className="flex items-center">
                {getTransactionIcon(tx.type)}
                <span className="text-white text-sm mr-2">{getTransactionLabel(tx.type)}</span>
              </div>
              
              {/* Asset */}
              <div className="text-white font-medium">{tx.symbol}</div>
              
              {/* Amount */}
              <div className="text-center text-white">
                {formatCrypto(tx.amount, tx.symbol)}
              </div>
              
              {/* Price */}
              <div className="text-center text-white">
                {formatCurrency(tx.price)}
              </div>
              
              {/* Value */}
              <div className="text-center">
                <div className="text-white font-medium">{formatCurrency(tx.value)}</div>
                {tx.fee > 0 && (
                  <div className="text-gray-400 text-xs">رسوم: ${tx.fee}</div>
                )}
              </div>
              
              {/* Status */}
              <div className="flex items-center justify-center">
                {getStatusIcon(tx.status)}
                <span className="text-xs text-gray-400 mr-2">
                  {tx.timestamp.toLocaleTimeString('ar-SA')}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PortfolioManager;