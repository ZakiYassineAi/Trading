import React, { useState, useEffect } from 'react';
import {
  Brain,
  Zap,
  TrendingUp,
  TrendingDown,
  Target,
  Shield,
  Activity,
  AlertCircle,
  CheckCircle,
  Clock,
  DollarSign,
  BarChart3,
  Settings,
  Play,
  Pause,
  RefreshCw
} from 'lucide-react';

interface AITradingBotProps {
  isActive?: boolean;
  onToggle?: (active: boolean) => void;
}

const AITradingBot: React.FC<AITradingBotProps> = ({
  isActive = false,
  onToggle
}) => {
  const [botStatus, setBotStatus] = useState({
    active: isActive,
    performance: {
      totalTrades: 147,
      winRate: 73.5,
      totalProfit: 2847.32,
      todayProfit: 234.56,
      avgHoldTime: '2h 34m',
      sharpeRatio: 2.14
    },
    currentAnalysis: {
      marketSentiment: 'صعودي',
      riskLevel: 'متوسط',
      nextAction: 'انتظار فرصة دخول',
      confidence: 87
    },
    recentSignals: [
      {
        timestamp: new Date(Date.now() - 10 * 60000),
        pair: 'BTC/USDT',
        action: 'BUY',
        confidence: 91,
        reason: 'كسر مستوى المقاومة مع حجم قوي',
        status: 'executed',
        profit: 156.78
      },
      {
        timestamp: new Date(Date.now() - 45 * 60000),
        pair: 'ETH/USDT',
        action: 'SELL',
        confidence: 85,
        reason: 'تشبع شرائي في RSI مع تباعد هبوطي',
        status: 'executed',
        profit: 89.34
      },
      {
        timestamp: new Date(Date.now() - 2 * 60 * 60000),
        pair: 'BNB/USDT',
        action: 'HOLD',
        confidence: 67,
        reason: 'عدم وضوح الاتجاه - انتظار إشارة أقوى',
        status: 'pending',
        profit: 0
      }
    ],
    strategies: [
      {
        name: 'التحليل الفني المتقدم',
        description: 'يحلل الأنماط والمؤشرات الفنية',
        active: true,
        weight: 35,
        performance: '+15.6%'
      },
      {
        name: 'تحليل المشاعر',
        description: 'يراقب مشاعر السوق والأخبار',
        active: true,
        weight: 25,
        performance: '+12.3%'
      },
      {
        name: 'الذكاء الاصطناعي التنبؤي',
        description: 'نماذج التعلم الآلي للتنبؤ بالحركة',
        active: true,
        weight: 30,
        performance: '+18.9%'
      },
      {
        name: 'إدارة المخاطر الذكية',
        description: 'تحسين نسبة المخاطرة للعائد',
        active: true,
        weight: 10,
        performance: '+8.7%'
      }
    ]
  });

  const [newsAnalysis, setNewsAnalysis] = useState([
    {
      headline: 'صندوق BlackRock يشتري 3,000 BTC إضافية',
      impact: 'إيجابي قوي',
      confidence: 92,
      timeframe: 'قصير-متوسط الأمد'
    },
    {
      headline: 'الفيدرالي الأمريكي يناقش أسعار الفائدة',
      impact: 'سلبي محتمل',
      confidence: 78,
      timeframe: 'متوسط الأمد'
    },
    {
      headline: 'Ethereum يتجه نحو ترقية جديدة',
      impact: 'إيجابي',
      confidence: 85,
      timeframe: 'طويل الأمد'
    }
  ]);

  useEffect(() => {
    // Simulate real-time updates
    const interval = setInterval(() => {
      setBotStatus(prev => ({
        ...prev,
        performance: {
          ...prev.performance,
          todayProfit: prev.performance.todayProfit + (Math.random() - 0.5) * 50
        },
        currentAnalysis: {
          ...prev.currentAnalysis,
          confidence: Math.max(60, Math.min(95, prev.currentAnalysis.confidence + (Math.random() - 0.5) * 10))
        }
      }));
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  const handleToggleBot = () => {
    const newStatus = !botStatus.active;
    setBotStatus(prev => ({ ...prev, active: newStatus }));
    onToggle?.(newStatus);
  };

  return (
    <div className="space-y-6">
      {/* AI Bot Header */}
      <div className="bg-gradient-to-r from-purple-900/20 to-blue-900/20 rounded-xl p-6 border border-purple-600/30">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <Brain className="h-8 w-8 text-purple-400 ml-3" />
            <div>
              <h2 className="text-2xl font-bold text-white">الوكيل التداولي الذكي</h2>
              <p className="text-purple-300">نظام تداول مدعوم بالذكاء الاصطناعي</p>
            </div>
          </div>

          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            <div className="text-left">
              <div className="text-sm text-gray-400">الحالة</div>
              <div className={`flex items-center text-sm font-medium ${
                botStatus.active ? 'text-green-400' : 'text-gray-400'
              }`}>
                <div className={`w-2 h-2 rounded-full ml-2 ${
                  botStatus.active ? 'bg-green-400 animate-pulse' : 'bg-gray-400'
                }`}></div>
                {botStatus.active ? 'نشط' : 'متوقف'}
              </div>
            </div>

            <button
              onClick={handleToggleBot}
              className={`p-3 rounded-lg transition-all ${
                botStatus.active
                  ? 'bg-red-600 hover:bg-red-700 text-white'
                  : 'bg-green-600 hover:bg-green-700 text-white'
              }`}
            >
              {botStatus.active ? (
                <Pause className="h-5 w-5" />
              ) : (
                <Play className="h-5 w-5" />
              )}
            </button>
          </div>
        </div>

        {/* Performance Metrics */}
        <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-white">{botStatus.performance.totalTrades}</div>
            <div className="text-sm text-purple-300">إجمالي الصفقات</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-400">{botStatus.performance.winRate}%</div>
            <div className="text-sm text-purple-300">معدل الربح</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-white">${botStatus.performance.totalProfit.toLocaleString()}</div>
            <div className="text-sm text-purple-300">إجمالي الأرباح</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-yellow-400">${botStatus.performance.todayProfit.toFixed(2)}</div>
            <div className="text-sm text-purple-300">ربح اليوم</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-white">{botStatus.performance.avgHoldTime}</div>
            <div className="text-sm text-purple-300">متوسط المدة</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-400">{botStatus.performance.sharpeRatio}</div>
            <div className="text-sm text-purple-300">نسبة شارب</div>
          </div>
        </div>
      </div>

      {/* Current Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Market Analysis */}
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <h3 className="text-xl font-bold text-white mb-4 flex items-center">
            <BarChart3 className="h-5 w-5 ml-2" />
            التحليل الحالي
          </h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-400">مشاعر السوق:</span>
              <span className="text-green-400 font-medium">{botStatus.currentAnalysis.marketSentiment}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400">مستوى المخاطرة:</span>
              <span className="text-yellow-400 font-medium">{botStatus.currentAnalysis.riskLevel}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400">الإجراء التالي:</span>
              <span className="text-blue-400 font-medium">{botStatus.currentAnalysis.nextAction}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400">مستوى الثقة:</span>
              <div className="flex items-center">
                <div className="w-24 h-2 bg-gray-700 rounded-full overflow-hidden ml-2">
                  <div 
                    className="h-full bg-gradient-to-r from-green-400 to-blue-400 rounded-full transition-all"
                    style={{ width: `${botStatus.currentAnalysis.confidence}%` }}
                  ></div>
                </div>
                <span className="text-white font-medium">{botStatus.currentAnalysis.confidence}%</span>
              </div>
            </div>
          </div>
        </div>

        {/* Active Strategies */}
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <h3 className="text-xl font-bold text-white mb-4 flex items-center">
            <Target className="h-5 w-5 ml-2" />
            الاستراتيجيات النشطة
          </h3>
          
          <div className="space-y-3">
            {botStatus.strategies.filter(s => s.active).map((strategy, index) => (
              <div key={index} className="bg-gray-900/50 rounded-lg p-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-white">{strategy.name}</span>
                  <div className="flex items-center">
                    <span className="text-sm text-green-400 ml-2">{strategy.performance}</span>
                    <span className="text-xs text-gray-400">{strategy.weight}%</span>
                  </div>
                </div>
                <p className="text-sm text-gray-400">{strategy.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Signals */}
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-white flex items-center">
            <Zap className="h-5 w-5 ml-2 text-yellow-400" />
            الإشارات الحديثة
          </h3>
          <button className="p-2 hover:bg-gray-700 rounded transition-colors">
            <RefreshCw className="h-4 w-4 text-gray-400" />
          </button>
        </div>
        
        <div className="space-y-3">
          {botStatus.recentSignals.map((signal, index) => (
            <div key={index} className="bg-gray-900/50 rounded-lg p-4 border border-gray-700">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  <span className="font-medium text-white ml-3">{signal.pair}</span>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    signal.action === 'BUY'
                      ? 'bg-green-600/20 text-green-400 border border-green-600/30'
                      : signal.action === 'SELL'
                      ? 'bg-red-600/20 text-red-400 border border-red-600/30'
                      : 'bg-yellow-600/20 text-yellow-400 border border-yellow-600/30'
                  }`}>
                    {signal.action === 'BUY' ? 'شراء' : signal.action === 'SELL' ? 'بيع' : 'انتظار'}
                  </span>
                  <div className="flex items-center ml-3">
                    {signal.status === 'executed' ? (
                      <CheckCircle className="h-4 w-4 text-green-400" />
                    ) : (
                      <Clock className="h-4 w-4 text-yellow-400" />
                    )}
                    <span className={`text-xs ml-1 ${
                      signal.status === 'executed' ? 'text-green-400' : 'text-yellow-400'
                    }`}>
                      {signal.status === 'executed' ? 'تم التنفيذ' : 'قيد الانتظار'}
                    </span>
                  </div>
                </div>
                <div className="flex items-center space-x-4 rtl:space-x-reverse">
                  <div className="text-sm text-gray-400">
                    الثقة: <span className="text-white">{signal.confidence}%</span>
                  </div>
                  <div className="text-sm">
                    {signal.profit > 0 ? (
                      <span className="text-green-400">+${signal.profit}</span>
                    ) : signal.profit < 0 ? (
                      <span className="text-red-400">${signal.profit}</span>
                    ) : (
                      <span className="text-gray-400">-</span>
                    )}
                  </div>
                  <div className="text-sm text-gray-400">
                    {signal.timestamp.toLocaleTimeString('ar-SA')}
                  </div>
                </div>
              </div>
              <p className="text-gray-400 text-sm">{signal.reason}</p>
            </div>
          ))}
        </div>
      </div>

      {/* News Analysis */}
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <h3 className="text-xl font-bold text-white mb-4 flex items-center">
          <AlertCircle className="h-5 w-5 ml-2 text-orange-400" />
          تحليل الأخبار والمشاعر
        </h3>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {newsAnalysis.map((news, index) => (
            <div key={index} className="bg-gray-900/50 rounded-lg p-4">
              <div className="mb-2">
                <div className={`inline-block px-2 py-1 rounded text-xs font-medium ${
                  news.impact.includes('إيجابي')
                    ? 'bg-green-600/20 text-green-400'
                    : news.impact.includes('سلبي')
                    ? 'bg-red-600/20 text-red-400'
                    : 'bg-yellow-600/20 text-yellow-400'
                }`}>
                  {news.impact}
                </div>
                <div className="text-xs text-gray-400 mt-1">
                  الثقة: {news.confidence}% • {news.timeframe}
                </div>
              </div>
              <p className="text-sm text-gray-300 leading-relaxed">{news.headline}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Bot Settings */}
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <h3 className="text-xl font-bold text-white mb-4 flex items-center">
          <Settings className="h-5 w-5 ml-2" />
          إعدادات الوكيل
        </h3>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div>
            <label className="text-sm text-gray-400 mb-2 block">الحد الأقصى للمخاطرة (%)</label>
            <input 
              type="range" 
              min="1" 
              max="10" 
              defaultValue="3" 
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>1%</span>
              <span>10%</span>
            </div>
          </div>
          
          <div>
            <label className="text-sm text-gray-400 mb-2 block">الحد الأدنى للثقة (%)</label>
            <input 
              type="range" 
              min="50" 
              max="95" 
              defaultValue="75" 
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>50%</span>
              <span>95%</span>
            </div>
          </div>
          
          <div>
            <label className="text-sm text-gray-400 mb-2 block">عدد الصفقات المتزامنة</label>
            <input 
              type="range" 
              min="1" 
              max="10" 
              defaultValue="5" 
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>1</span>
              <span>10</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AITradingBot;