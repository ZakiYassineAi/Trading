import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Plus,
  Minus,
  Calculator,
  Target,
  Shield,
  Zap,
  AlertTriangle,
  Clock,
  CheckCircle
} from 'lucide-react';

interface TradingPanelProps {
  symbol?: string;
  currentPrice?: number;
  isLiveTrading?: boolean;
}

interface OrderData {
  type: 'market' | 'limit' | 'stop';
  side: 'buy' | 'sell';
  quantity: number;
  price?: number;
  stopPrice?: number;
  total: number;
}

const TradingPanel: React.FC<TradingPanelProps> = ({
  symbol = 'BTC/USDT',
  currentPrice = 67234.56,
  isLiveTrading = false
}) => {
  const [activeTab, setActiveTab] = useState<'spot' | 'futures' | 'options'>('spot');
  const [orderType, setOrderType] = useState<'market' | 'limit' | 'stop'>('limit');
  const [side, setSide] = useState<'buy' | 'sell'>('buy');
  const [orderData, setOrderData] = useState<OrderData>({
    type: 'limit',
    side: 'buy',
    quantity: 0,
    price: currentPrice,
    total: 0
  });
  
  const [balance, setBalance] = useState({
    BTC: 0.5643,
    USDT: 25847.92,
    available: isLiveTrading ? 25847.92 : 10000.00
  });
  
  const [openOrders, setOpenOrders] = useState([
    {
      id: '1',
      symbol: 'BTC/USDT',
      side: 'buy' as const,
      type: 'limit' as const,
      quantity: 0.1234,
      price: 66500.00,
      filled: 0,
      status: 'open' as const,
      timestamp: new Date(Date.now() - 5 * 60000)
    },
    {
      id: '2',
      symbol: 'ETH/USDT',
      side: 'sell' as const,
      type: 'limit' as const,
      quantity: 2.5,
      price: 3500.00,
      filled: 0.8,
      status: 'partially_filled' as const,
      timestamp: new Date(Date.now() - 15 * 60000)
    }
  ]);
  
  const [recentOrders, setRecentOrders] = useState([
    {
      id: '3',
      symbol: 'BTC/USDT',
      side: 'buy' as const,
      type: 'market' as const,
      quantity: 0.05,
      price: 67100.00,
      status: 'filled' as const,
      timestamp: new Date(Date.now() - 2 * 60000),
      pnl: 156.78
    },
    {
      id: '4',
      symbol: 'ETH/USDT',
      side: 'sell' as const,
      type: 'limit' as const,
      quantity: 1.2,
      price: 3450.00,
      status: 'filled' as const,
      timestamp: new Date(Date.now() - 10 * 60000),
      pnl: -23.45
    }
  ]);

  useEffect(() => {
    // Update order total when quantity or price changes
    if (orderData.type === 'market') {
      setOrderData(prev => ({
        ...prev,
        total: prev.quantity * currentPrice
      }));
    } else {
      setOrderData(prev => ({
        ...prev,
        total: prev.quantity * (prev.price || 0)
      }));
    }
  }, [orderData.quantity, orderData.price, orderData.type, currentPrice]);

  const handleQuantityChange = (value: number) => {
    setOrderData(prev => ({ ...prev, quantity: Math.max(0, value) }));
  };

  const handlePriceChange = (value: number) => {
    setOrderData(prev => ({ ...prev, price: Math.max(0, value) }));
  };

  const handlePercentageClick = (percentage: number) => {
    const availableBalance = side === 'buy' ? balance.USDT : balance.BTC;
    const price = orderData.type === 'market' ? currentPrice : (orderData.price || currentPrice);
    
    if (side === 'buy') {
      const totalToSpend = availableBalance * (percentage / 100);
      const quantity = totalToSpend / price;
      setOrderData(prev => ({ ...prev, quantity, total: totalToSpend }));
    } else {
      const quantity = availableBalance * (percentage / 100);
      setOrderData(prev => ({ ...prev, quantity, total: quantity * price }));
    }
  };

  const handleSubmitOrder = () => {
    if (orderData.quantity <= 0) return;
    
    const newOrder = {
      id: Date.now().toString(),
      symbol,
      side,
      type: orderData.type,
      quantity: orderData.quantity,
      price: orderData.price || currentPrice,
      filled: 0,
      status: orderData.type === 'market' ? 'filled' as const : 'open' as const,
      timestamp: new Date()
    };
    
    if (orderData.type === 'market') {
      setRecentOrders(prev => [{
        ...newOrder,
        pnl: Math.random() * 200 - 100 // Random P&L for demo
      }, ...prev]);
    } else {
      setOpenOrders(prev => [newOrder, ...prev]);
    }
    
    // Reset form
    setOrderData({
      type: orderData.type,
      side,
      quantity: 0,
      price: orderData.type === 'limit' ? orderData.price : undefined,
      total: 0
    });
  };

  const cancelOrder = (orderId: string) => {
    setOpenOrders(prev => prev.filter(order => order.id !== orderId));
  };

  const getOrderStatusIcon = (status: string) => {
    switch (status) {
      case 'filled': return <CheckCircle className="h-4 w-4 text-green-400" />;
      case 'open': return <Clock className="h-4 w-4 text-yellow-400" />;
      case 'partially_filled': return <Target className="h-4 w-4 text-blue-400" />;
      default: return <AlertTriangle className="h-4 w-4 text-red-400" />;
    }
  };

  const getOrderStatusLabel = (status: string) => {
    switch (status) {
      case 'filled': return 'تم التنفيذ';
      case 'open': return 'مفتوح';
      case 'partially_filled': return 'تنفيذ جزئي';
      default: return 'ملغي';
    }
  };

  return (
    <div className="space-y-6">
      {/* Trading Mode Warning */}
      {isLiveTrading && (
        <div className="bg-red-900/20 border border-red-600/30 rounded-xl p-4">
          <div className="flex items-center">
            <AlertTriangle className="h-5 w-5 text-red-400 ml-2" />
            <span className="text-red-400 font-medium">
              تحذير: أنت في وضع التداول الحقيقي. جميع الصفقات ستربط بالبورصات الحقيقية.
            </span>
          </div>
        </div>
      )}

      {/* Trading Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Order Form */}
        <div className="lg:col-span-1 bg-gray-800 rounded-xl p-6 border border-gray-700">
          {/* Trading Type Tabs */}
          <div className="flex mb-6">
            {[{ id: 'spot', label: 'فوري' }, { id: 'futures', label: 'عقود' }, { id: 'options', label: 'خيارات' }].map(({ id, label }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id as any)}
                className={`flex-1 py-2 px-4 text-sm font-medium transition-colors ${
                  activeTab === id
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-400 hover:text-white hover:bg-gray-700'
                } ${
                  id === 'spot' ? 'rounded-r-none rounded-l' :
                  id === 'options' ? 'rounded-l-none rounded-r' : 'rounded-none'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {/* Buy/Sell Toggle */}
          <div className="flex mb-4">
            <button
              onClick={() => setSide('buy')}
              className={`flex-1 py-3 px-4 font-medium transition-colors rounded-l ${
                side === 'buy'
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              شراء
            </button>
            <button
              onClick={() => setSide('sell')}
              className={`flex-1 py-3 px-4 font-medium transition-colors rounded-r ${
                side === 'sell'
                  ? 'bg-red-600 text-white'
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              بيع
            </button>
          </div>

          {/* Order Type */}
          <div className="mb-4">
            <label className="text-sm text-gray-400 mb-2 block">نوع الأمر</label>
            <select
              value={orderType}
              onChange={(e) => {
                const newType = e.target.value as 'market' | 'limit' | 'stop';
                setOrderType(newType);
                setOrderData(prev => ({ ...prev, type: newType }));
              }}
              className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white"
            >
              <option value="market">فوري (Market)</option>
              <option value="limit">محدد (Limit)</option>
              <option value="stop">إيقاف (Stop)</option>
            </select>
          </div>

          {/* Price Input (for Limit/Stop orders) */}
          {orderType !== 'market' && (
            <div className="mb-4">
              <label className="text-sm text-gray-400 mb-2 block">
                {orderType === 'limit' ? 'السعر' : 'سعر الإيقاف'} (USDT)
              </label>
              <div className="relative">
                <input
                  type="number"
                  value={orderData.price || ''}
                  onChange={(e) => handlePriceChange(Number(e.target.value))}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white pr-20"
                  placeholder="0.00"
                />
                <button 
                  onClick={() => setOrderData(prev => ({ ...prev, price: currentPrice }))}
                  className="absolute left-2 top-1/2 transform -translate-y-1/2 text-xs text-blue-400 hover:text-blue-300"
                >
                  السوق
                </button>
              </div>
            </div>
          )}

          {/* Quantity Input */}
          <div className="mb-4">
            <label className="text-sm text-gray-400 mb-2 block">الكمية (BTC)</label>
            <div className="relative">
              <input
                type="number"
                value={orderData.quantity || ''}
                onChange={(e) => handleQuantityChange(Number(e.target.value))}
                className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white"
                placeholder="0.00"
              />
              <div className="absolute left-2 top-1/2 transform -translate-y-1/2">
                <button 
                  onClick={() => handleQuantityChange(orderData.quantity - 0.001)}
                  className="text-gray-400 hover:text-white mr-1"
                >
                  <Minus className="h-4 w-4" />
                </button>
                <button 
                  onClick={() => handleQuantityChange(orderData.quantity + 0.001)}
                  className="text-gray-400 hover:text-white"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Percentage Buttons */}
          <div className="mb-4">
            <div className="grid grid-cols-4 gap-2">
              {[25, 50, 75, 100].map(percentage => (
                <button
                  key={percentage}
                  onClick={() => handlePercentageClick(percentage)}
                  className="py-2 px-3 bg-gray-700 hover:bg-gray-600 text-gray-300 text-xs rounded transition-colors"
                >
                  {percentage}%
                </button>
              ))}
            </div>
          </div>

          {/* Total */}
          <div className="mb-4">
            <label className="text-sm text-gray-400 mb-2 block">الإجمالي (USDT)</label>
            <div className="p-3 bg-gray-900 border border-gray-600 rounded-lg">
              <span className="text-white text-lg font-medium">
                {orderData.total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>

          {/* Available Balance */}
          <div className="mb-6">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">الرصيد المتاح:</span>
              <span className="text-white">
                {side === 'buy' 
                  ? `${balance.USDT.toLocaleString()} USDT`
                  : `${balance.BTC.toLocaleString()} BTC`
                }
              </span>
            </div>
          </div>

          {/* Submit Button */}
          <button
            onClick={handleSubmitOrder}
            disabled={orderData.quantity <= 0}
            className={`w-full py-4 px-6 font-semibold rounded-lg transition-all ${
              side === 'buy'
                ? 'bg-green-600 hover:bg-green-700 text-white'
                : 'bg-red-600 hover:bg-red-700 text-white'
            } disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center`}
          >
            {isLiveTrading && <Zap className="h-5 w-5 ml-2" />}
            {side === 'buy' ? 'شراء' : 'بيع'} {symbol}
            {isLiveTrading && <span className="text-xs mr-2">(حقيقي)</span>}
          </button>
        </div>

        {/* Open Orders */}
        <div className="lg:col-span-2 space-y-6">
          {/* Open Orders */}
          <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
            <h3 className="text-lg font-bold text-white mb-4 flex items-center">
              <Clock className="h-5 w-5 ml-2 text-yellow-400" />
              الأوامر المفتوحة ({openOrders.length})
            </h3>
            
            {openOrders.length === 0 ? (
              <div className="text-center py-8">
                <Shield className="h-12 w-12 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-400">لا توجد أوامر مفتوحة</p>
              </div>
            ) : (
              <div className="space-y-2">
                {/* Headers */}
                <div className="grid grid-cols-7 gap-4 text-sm text-gray-400 font-medium">
                  <div>الزوج</div>
                  <div>النوع</div>
                  <div className="text-center">الكمية</div>
                  <div className="text-center">السعر</div>
                  <div className="text-center">منفذ</div>
                  <div className="text-center">الحالة</div>
                  <div className="text-center">إجراء</div>
                </div>
                
                {openOrders.map(order => (
                  <div key={order.id} className="grid grid-cols-7 gap-4 p-3 bg-gray-900/50 rounded-lg hover:bg-gray-700/50 transition-colors">
                    <div className="flex items-center">
                      <div className={`w-2 h-2 rounded-full ml-2 ${
                        order.side === 'buy' ? 'bg-green-400' : 'bg-red-400'
                      }`} />
                      <span className="text-white text-sm">{order.symbol}</span>
                    </div>
                    
                    <div className={`text-sm font-medium ${
                      order.side === 'buy' ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {order.side === 'buy' ? 'شراء' : 'بيع'} {order.type.toUpperCase()}
                    </div>
                    
                    <div className="text-center text-white text-sm">
                      {order.quantity.toFixed(4)}
                    </div>
                    
                    <div className="text-center text-white text-sm">
                      ${order.price.toLocaleString()}
                    </div>
                    
                    <div className="text-center text-white text-sm">
                      {order.filled.toFixed(4)} ({((order.filled / order.quantity) * 100).toFixed(1)}%)
                    </div>
                    
                    <div className="flex items-center justify-center">
                      {getOrderStatusIcon(order.status)}
                      <span className="text-xs text-gray-400 mr-2">
                        {getOrderStatusLabel(order.status)}
                      </span>
                    </div>
                    
                    <div className="flex justify-center">
                      <button
                        onClick={() => cancelOrder(order.id)}
                        className="text-red-400 hover:text-red-300 text-sm"
                      >
                        إلغاء
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recent Orders */}
          <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
            <h3 className="text-lg font-bold text-white mb-4 flex items-center">
              <CheckCircle className="h-5 w-5 ml-2 text-green-400" />
              آخر الصفقات ({recentOrders.length})
            </h3>
            
            <div className="space-y-2">
              {/* Headers */}
              <div className="grid grid-cols-7 gap-4 text-sm text-gray-400 font-medium">
                <div>الزوج</div>
                <div>النوع</div>
                <div className="text-center">الكمية</div>
                <div className="text-center">السعر</div>
                <div className="text-center">ر/خ</div>
                <div className="text-center">الوقت</div>
                <div className="text-center">الحالة</div>
              </div>
              
              {recentOrders.map(order => (
                <div key={order.id} className="grid grid-cols-7 gap-4 p-3 bg-gray-900/50 rounded-lg">
                  <div className="flex items-center">
                    <div className={`w-2 h-2 rounded-full ml-2 ${
                      order.side === 'buy' ? 'bg-green-400' : 'bg-red-400'
                    }`} />
                    <span className="text-white text-sm">{order.symbol}</span>
                  </div>
                  
                  <div className={`text-sm font-medium ${
                    order.side === 'buy' ? 'text-green-400' : 'text-red-400'
                  }`}>
                    {order.side === 'buy' ? 'شراء' : 'بيع'} {order.type.toUpperCase()}
                  </div>
                  
                  <div className="text-center text-white text-sm">
                    {order.quantity.toFixed(4)}
                  </div>
                  
                  <div className="text-center text-white text-sm">
                    ${order.price.toLocaleString()}
                  </div>
                  
                  <div className={`text-center text-sm font-medium ${
                    order.pnl && order.pnl > 0 ? 'text-green-400' : 'text-red-400'
                  }`}>
                    {order.pnl ? (order.pnl > 0 ? '+' : '') + order.pnl.toFixed(2) : '-'}
                  </div>
                  
                  <div className="text-center text-gray-400 text-xs">
                    {order.timestamp.toLocaleTimeString('ar-SA')}
                  </div>
                  
                  <div className="flex items-center justify-center">
                    {getOrderStatusIcon(order.status)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TradingPanel;