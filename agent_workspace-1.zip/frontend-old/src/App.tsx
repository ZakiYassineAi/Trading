import React, { useState } from 'react';
import { Header, Sidebar, Footer } from './components/layout';
import './index.css';

function App() {
  const [activeSection, setActiveSection] = useState('dashboard');
  
  // Mock user data
  const currentUser = {
    name: 'محمد أحمد',
    avatar: null // Will use default avatar
  };

  // Handle section changes from sidebar
  const handleSectionChange = (section: string) => {
    setActiveSection(section);
  };

  // Render main content based on active section
  const renderMainContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h1 className="text-3xl font-bold text-white">لوحة التحكم</h1>
              <div className="text-sm text-gray-400">
                آخر تحديث: {new Date().toLocaleString('ar-SA')}
              </div>
            </div>
            
            {/* Quick Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">رصيد المحفظة</p>
                    <p className="text-2xl font-bold text-white mt-1">$10,000</p>
                  </div>
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-green-500 rounded-lg flex items-center justify-center">
                    <span className="text-white font-bold text-lg">$</span>
                  </div>
                </div>
                <div className="mt-4 text-sm">
                  <span className="text-green-400">+2.5%</span>
                  <span className="text-gray-400 mr-2">منذ بداية الشهر</span>
                </div>
              </div>

              <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">عدد الاستراتيجيات</p>
                    <p className="text-2xl font-bold text-white mt-1">12</p>
                  </div>
                  <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                    <span className="text-white font-bold text-lg">⚙️</span>
                  </div>
                </div>
                <div className="mt-4 text-sm">
                  <span className="text-blue-400">8 فعالة</span>
                  <span className="text-gray-400 mr-2">, 4 معطلة</span>
                </div>
              </div>

              <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">عدد الصفقات</p>
                    <p className="text-2xl font-bold text-white mt-1">847</p>
                  </div>
                  <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg flex items-center justify-center">
                    <span className="text-white font-bold text-lg">💹</span>
                  </div>
                </div>
                <div className="mt-4 text-sm">
                  <span className="text-green-400">68% ربحية</span>
                  <span className="text-gray-400 mr-2">, 32% خاسرة</span>
                </div>
              </div>

              <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">نسبة شارب</p>
                    <p className="text-2xl font-bold text-white mt-1">1.85</p>
                  </div>
                  <div className="w-12 h-12 bg-gradient-to-r from-teal-500 to-cyan-500 rounded-lg flex items-center justify-center">
                    <span className="text-white font-bold text-lg">📈</span>
                  </div>
                </div>
                <div className="mt-4 text-sm">
                  <span className="text-green-400">ممتاز</span>
                  <span className="text-gray-400 mr-2">> 1.0</span>
                </div>
              </div>
            </div>

            {/* Welcome Message */}
            <div className="bg-gradient-to-r from-blue-600/20 to-green-600/20 rounded-xl p-6 border border-blue-500/30">
              <h2 className="text-xl font-bold text-white mb-2">مرحباً بك في منصة التداول الكمي</h2>
              <p className="text-gray-300 leading-relaxed">
                ابدأ رحلتك في عالم التداول الكمي مع محركنا المتقدم لاختبار الاستراتيجيات وتحليل الأداء. جميع العمليات آمنة وورقية 100%.
              </p>
              <div className="mt-4 flex space-x-4 rtl:space-x-reverse">
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors">
                  ابدأ باك-تست جديد
                </button>
                <button className="bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded-lg transition-colors">
                  عرض الدروس التعليمية
                </button>
              </div>
            </div>
          </div>
        );
      
      default:
        return (
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="text-6xl mb-4">🚧</div>
              <h2 className="text-2xl font-bold text-white mb-2">تحت التطوير</h2>
              <p className="text-gray-400">هذا القسم قيد التطوير حالياً</p>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-950 flex flex-col">
      {/* Header */}
      <Header currentUser={currentUser} />
      
      <div className="flex flex-1">
        {/* Sidebar */}
        <Sidebar 
          activeSection={activeSection}
          onSectionChange={handleSectionChange}
        />
        
        {/* Main Content */}
        <main className="flex-1 p-6 overflow-y-auto">
          <div className="max-w-7xl mx-auto">
            {renderMainContent()}
          </div>
        </main>
      </div>
      
      {/* Footer */}
      <Footer />
    </div>
  );
}

export default App;