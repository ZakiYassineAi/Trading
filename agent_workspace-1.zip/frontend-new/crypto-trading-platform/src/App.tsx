import React, { useState } from 'react';
import { Header, Sidebar, Footer } from './components/layout';
import TradingDashboard from './components/trading/TradingDashboard';
import TradingView from './components/trading/TradingView';
import AITradingBot from './components/trading/AITradingBot';
import OrderBook from './components/trading/OrderBook';
import PortfolioManager from './components/trading/PortfolioManager';
import TradingPanel from './components/trading/TradingPanel';
import NewsAndSentiment from './components/trading/NewsAndSentiment';
import './index.css';

function App() {
  const [activeSection, setActiveSection] = useState('dashboard');
  const [isLiveTrading, setIsLiveTrading] = useState(false);
  
  // Mock user data
  const currentUser = {
    name: 'محمد أحمد',
    avatar: null // Will use default avatar
  };

  // Handle section changes from sidebar
  const handleSectionChange = (section: string) => {
    setActiveSection(section);
  };

  // Handle trading mode toggle
  const handleTradingModeToggle = (isLive: boolean) => {
    setIsLiveTrading(isLive);
  };

  // Render main content based on active section
  const renderMainContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return (
          <div className="space-y-6">
            <TradingDashboard 
              isLiveTrading={isLiveTrading}
              onToggleMode={handleTradingModeToggle}
            />
            
            {/* Advanced Trading Charts */}
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
              <div className="xl:col-span-2">
                <TradingView symbol="BTCUSDT" interval="1H" height={500} />
              </div>
              <div>
                <OrderBook symbol="BTC/USDT" precision={2} />
              </div>
            </div>
          </div>
        );
      
      case 'backtest':
        return (
          <div className="space-y-6">
            <TradingPanel 
              symbol="BTC/USDT"
              currentPrice={67234.56}
              isLiveTrading={isLiveTrading}
            />
            
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              <TradingView symbol="BTCUSDT" interval="4H" height={400} />
              <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                <h3 className="text-xl font-bold text-white mb-4">محرك الباك-تست المتقدم</h3>
                <div className="text-center py-12">
                  <div className="text-6xl mb-4">🔬</div>
                  <h3 className="text-xl font-bold text-white mb-2">جاري التطوير</h3>
                  <p className="text-gray-400">محرك باك-تست متقدم مع استراتيجيات متعددة</p>
                </div>
              </div>
            </div>
          </div>
        );
      
      case 'portfolio':
        return <PortfolioManager />;
      
      case 'ai-bot':
        return <AITradingBot isActive={true} />;
      
      case 'alerts':
        return <NewsAndSentiment />;
      
      case 'education':
        return (
          <div className="flex items-center justify-center h-96">
            <div className="text-center">
              <div className="text-6xl mb-4">🎓</div>
              <h2 className="text-2xl font-bold text-white mb-2">الوحدة التعليمية</h2>
              <p className="text-gray-400">دروس DeFi تفاعلية وشرح الاستراتيجيات - جاري التطوير</p>
            </div>
          </div>
        );
      
      case 'analytics':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <TradingView symbol="BTCUSDT" interval="1D" height={400} />
              <TradingView symbol="ETHUSDT" interval="1D" height={400} />
            </div>
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <div className="text-6xl mb-4">📊</div>
                <h2 className="text-2xl font-bold text-white mb-2">التحليلات المتقدمة</h2>
                <p className="text-gray-400">تحليلات عميقة للسوق والاتجاهات - جاري التطوير</p>
              </div>
            </div>
          </div>
        );
      
      case 'performance':
        return (
          <div className="space-y-6">
            <PortfolioManager />
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <div className="text-6xl mb-4">📈</div>
                <h2 className="text-2xl font-bold text-white mb-2">تقارير الأداء</h2>
                <p className="text-gray-400">تقارير مفصلة لأداء الاستراتيجيات - جاري التطوير</p>
              </div>
            </div>
          </div>
        );
      
      case 'risk':
        return (
          <div className="flex items-center justify-center h-96">
            <div className="text-center">
              <div className="text-6xl mb-4">🛡️</div>
              <h2 className="text-2xl font-bold text-white mb-2">إدارة المخاطر</h2>
              <p className="text-gray-400">أدوات متقدمة لتقييم وإدارة المخاطر - جاري التطوير</p>
            </div>
          </div>
        );
      
      default:
        return (
          <div className="flex items-center justify-center h-96">
            <div className="text-center">
              <div className="text-6xl mb-4">🚧</div>
              <h2 className="text-2xl font-bold text-white mb-2">تحت التطوير</h2>
              <p className="text-gray-400">هذا القسم قيد التطوير حالياً</p>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-950 flex flex-col">
      {/* Header */}
      <Header currentUser={currentUser} />
      
      <div className="flex flex-1">
        {/* Sidebar */}
        <Sidebar 
          activeSection={activeSection}
          onSectionChange={handleSectionChange}
        />
        
        {/* Main Content */}
        <main className="flex-1 p-6 overflow-y-auto">
          <div className="max-w-[1600px] mx-auto">
            {renderMainContent()}
          </div>
        </main>
      </div>
      
      {/* Footer */}
      <Footer />
    </div>
  );
}

export default App;