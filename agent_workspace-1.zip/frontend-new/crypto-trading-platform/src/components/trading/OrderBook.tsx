import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  TrendingDown,
  Activity,
  Layers,
  DollarSign,
  Volume2,
  RefreshCw,
  Maximize2
} from 'lucide-react';

interface OrderBookProps {
  symbol?: string;
  precision?: number;
}

interface Order {
  price: number;
  quantity: number;
  total: number;
}

const OrderBook: React.FC<OrderBookProps> = ({
  symbol = 'BTC/USDT',
  precision = 2
}) => {
  const [spread, setSpread] = useState(0);
  const [lastPrice, setLastPrice] = useState(67234.56);
  const [priceChange, setPriceChange] = useState(2.34);
  
  // Generate realistic order book data
  const generateOrders = (basePrice: number, isBuy: boolean, count: number = 20): Order[] => {
    const orders: Order[] = [];
    const direction = isBuy ? -1 : 1;
    const maxSpread = basePrice * 0.001; // 0.1% spread
    
    for (let i = 0; i < count; i++) {
      const priceOffset = direction * (Math.random() * maxSpread * (i + 1) / count);
      const price = basePrice + priceOffset;
      const quantity = Math.random() * 5 + 0.1;
      const total = price * quantity;
      
      orders.push({
        price: Math.max(0, price),
        quantity,
        total
      });
    }
    
    return isBuy 
      ? orders.sort((a, b) => b.price - a.price) // Buy orders: highest first
      : orders.sort((a, b) => a.price - b.price); // Sell orders: lowest first
  };

  const [buyOrders, setBuyOrders] = useState<Order[]>(generateOrders(lastPrice, true));
  const [sellOrders, setSellOrders] = useState<Order[]>(generateOrders(lastPrice, false));
  const [recentTrades, setRecentTrades] = useState([
    { price: 67234.56, quantity: 0.245, time: new Date(Date.now() - 1000), type: 'buy' as const },
    { price: 67230.12, quantity: 1.876, time: new Date(Date.now() - 3000), type: 'sell' as const },
    { price: 67235.89, quantity: 0.567, time: new Date(Date.now() - 5000), type: 'buy' as const },
    { price: 67228.45, quantity: 2.134, time: new Date(Date.now() - 8000), type: 'sell' as const },
    { price: 67240.78, quantity: 0.892, time: new Date(Date.now() - 12000), type: 'buy' as const }
  ]);

  useEffect(() => {
    // Simulate real-time updates
    const interval = setInterval(() => {
      const newPrice = lastPrice + (Math.random() - 0.5) * 100;
      setLastPrice(newPrice);
      setPriceChange((newPrice - lastPrice) / lastPrice * 100);
      
      // Update order book
      setBuyOrders(generateOrders(newPrice, true));
      setSellOrders(generateOrders(newPrice, false));
      
      // Calculate spread
      const highestBuy = Math.max(...buyOrders.map(o => o.price));
      const lowestSell = Math.min(...sellOrders.map(o => o.price));
      setSpread(lowestSell - highestBuy);
      
      // Add new trade
      const newTrade = {
        price: newPrice,
        quantity: Math.random() * 2 + 0.1,
        time: new Date(),
        type: Math.random() > 0.5 ? 'buy' as const : 'sell' as const
      };
      
      setRecentTrades(prev => [newTrade, ...prev.slice(0, 19)]);
    }, 3000);

    return () => clearInterval(interval);
  }, [lastPrice, buyOrders, sellOrders]);

  const formatPrice = (price: number) => price.toFixed(precision);
  const formatQuantity = (qty: number) => qty.toFixed(4);
  const formatTotal = (total: number) => total.toFixed(2);

  const maxBuyQuantity = Math.max(...buyOrders.map(o => o.quantity));
  const maxSellQuantity = Math.max(...sellOrders.map(o => o.quantity));

  return (
    <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-gray-700 bg-gray-900/50">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Layers className="h-5 w-5 text-blue-400 ml-2" />
            <h3 className="text-lg font-bold text-white">سجل الطلبات</h3>
            <span className="text-gray-400 text-sm mr-2">({symbol})</span>
          </div>
          
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <div className="text-right">
              <div className="text-sm text-gray-400">الهامش</div>
              <div className="text-white font-medium">${spread.toFixed(2)}</div>
            </div>
            <button className="p-2 hover:bg-gray-700 rounded transition-colors">
              <RefreshCw className="h-4 w-4 text-gray-400" />
            </button>
            <button className="p-2 hover:bg-gray-700 rounded transition-colors">
              <Maximize2 className="h-4 w-4 text-gray-400" />
            </button>
          </div>
        </div>
      </div>

      <div className="flex h-[600px]">
        {/* Order Book */}
        <div className="flex-1 p-4">
          {/* Current Price */}
          <div className="mb-4 p-3 bg-gray-900/50 rounded-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <span className="text-gray-400 text-sm ml-2">السعر الحالي:</span>
                <span className="text-xl font-bold text-white">${formatPrice(lastPrice)}</span>
              </div>
              <div className={`flex items-center text-sm ${
                priceChange >= 0 ? 'text-green-400' : 'text-red-400'
              }`}>
                {priceChange >= 0 ? (
                  <TrendingUp className="h-4 w-4 ml-1" />
                ) : (
                  <TrendingDown className="h-4 w-4 ml-1" />
                )}
                {Math.abs(priceChange).toFixed(2)}%
              </div>
            </div>
          </div>

          {/* Headers */}
          <div className="grid grid-cols-3 gap-4 mb-2 text-xs text-gray-400 font-medium">
            <div className="text-right">السعر (USDT)</div>
            <div className="text-center">الكمية (BTC)</div>
            <div className="text-left">الإجمالي</div>
          </div>

          {/* Sell Orders (Red) */}
          <div className="mb-4">
            <div className="text-xs text-red-400 font-medium mb-2 flex items-center">
              <TrendingUp className="h-3 w-3 ml-1" />
              أوامر البيع
            </div>
            <div className="space-y-1 max-h-48 overflow-y-auto">
              {sellOrders.slice(0, 12).reverse().map((order, index) => {
                const widthPercent = (order.quantity / maxSellQuantity) * 100;
                return (
                  <div 
                    key={`sell-${index}`} 
                    className="relative grid grid-cols-3 gap-4 text-xs py-1 hover:bg-red-900/20 transition-colors cursor-pointer"
                  >
                    <div 
                      className="absolute left-0 top-0 bottom-0 bg-red-500/10 transition-all"
                      style={{ width: `${widthPercent}%` }}
                    />
                    <div className="text-right text-red-400 relative z-10">{formatPrice(order.price)}</div>
                    <div className="text-center text-white relative z-10">{formatQuantity(order.quantity)}</div>
                    <div className="text-left text-gray-300 relative z-10">{formatTotal(order.total)}</div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Spread Indicator */}
          <div className="my-3 p-2 bg-yellow-900/20 border border-yellow-600/30 rounded text-center">
            <div className="text-yellow-400 text-xs">
              هامش السعر: ${spread.toFixed(2)} ({((spread/lastPrice)*100).toFixed(3)}%)
            </div>
          </div>

          {/* Buy Orders (Green) */}
          <div>
            <div className="text-xs text-green-400 font-medium mb-2 flex items-center">
              <TrendingDown className="h-3 w-3 ml-1" />
              أوامر الشراء
            </div>
            <div className="space-y-1 max-h-48 overflow-y-auto">
              {buyOrders.slice(0, 12).map((order, index) => {
                const widthPercent = (order.quantity / maxBuyQuantity) * 100;
                return (
                  <div 
                    key={`buy-${index}`} 
                    className="relative grid grid-cols-3 gap-4 text-xs py-1 hover:bg-green-900/20 transition-colors cursor-pointer"
                  >
                    <div 
                      className="absolute left-0 top-0 bottom-0 bg-green-500/10 transition-all"
                      style={{ width: `${widthPercent}%` }}
                    />
                    <div className="text-right text-green-400 relative z-10">{formatPrice(order.price)}</div>
                    <div className="text-center text-white relative z-10">{formatQuantity(order.quantity)}</div>
                    <div className="text-left text-gray-300 relative z-10">{formatTotal(order.total)}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Recent Trades */}
        <div className="w-80 border-r border-gray-700 p-4">
          <div className="flex items-center mb-4">
            <Activity className="h-4 w-4 text-gray-400 ml-2" />
            <h4 className="text-sm font-medium text-white">آخر الصفقات</h4>
          </div>
          
          {/* Trade Headers */}
          <div className="grid grid-cols-3 gap-2 mb-2 text-xs text-gray-400 font-medium">
            <div className="text-right">السعر</div>
            <div className="text-center">الكمية</div>
            <div className="text-left">الوقت</div>
          </div>

          {/* Trade List */}
          <div className="space-y-1 max-h-[500px] overflow-y-auto">
            {recentTrades.map((trade, index) => (
              <div 
                key={index}
                className="grid grid-cols-3 gap-2 text-xs py-1 hover:bg-gray-700/50 transition-colors"
              >
                <div className={`text-right font-medium ${
                  trade.type === 'buy' ? 'text-green-400' : 'text-red-400'
                }`}>
                  {formatPrice(trade.price)}
                </div>
                <div className="text-center text-white">{formatQuantity(trade.quantity)}</div>
                <div className="text-left text-gray-400">
                  {trade.time.toLocaleTimeString('ar-SA', { 
                    hour12: false,
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit'
                  })}
                </div>
              </div>
            ))}
          </div>

          {/* Trade Summary */}
          <div className="mt-4 p-3 bg-gray-900/50 rounded">
            <div className="text-xs text-gray-400 mb-2">ملخص 24 ساعة</div>
            <div className="space-y-1 text-xs">
              <div className="flex justify-between">
                <span className="text-gray-400">عدد الصفقات:</span>
                <span className="text-white">8,234</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">الحجم:</span>
                <span className="text-white">1,234.56 BTC</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">أعلى سعر:</span>
                <span className="text-white">${formatPrice(lastPrice + 1200)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">أقل سعر:</span>
                <span className="text-white">${formatPrice(lastPrice - 800)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderBook;