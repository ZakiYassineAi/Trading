import React, { useState, useEffect } from 'react';
import {
  Newspaper,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Clock,
  ExternalLink,
  RefreshCw,
  Filter,
  Search,
  Globe,
  Target,
  Zap
} from 'lucide-react';

interface NewsItem {
  id: string;
  title: string;
  summary: string;
  source: string;
  timestamp: Date;
  impact: 'positive' | 'negative' | 'neutral';
  confidence: number;
  tags: string[];
  url: string;
  sentiment: number; // -1 to 1
}

interface MarketSentiment {
  overall: number;
  fear_greed: number;
  social: number;
  news: number;
  trend: 'bullish' | 'bearish' | 'neutral';
}

const NewsAndSentiment: React.FC = () => {
  const [news, setNews] = useState<NewsItem[]>([
    {
      id: '1',
      title: 'صندوق BlackRock يضيف 3,500 بيتكوين إضافية في يوم واحد',
      summary: 'اشترى أكبر مدير أصول في العالم كمية ضخمة من البيتكوين في يوم واحد، مما يعكس الثقة المتزايدة في العملة الرقمية',
      source: 'Bloomberg',
      timestamp: new Date(Date.now() - 10 * 60000),
      impact: 'positive',
      confidence: 92,
      tags: ['Bitcoin', 'ETF', 'Institutional'],
      url: '#',
      sentiment: 0.8
    },
    {
      id: '2', 
      title: 'الفيدرالي الأمريكي يناقش رفع أسعار الفائدة مرة أخرى',
      summary: 'تشير المؤشرات إلى إمكانية رفع أسعار الفائدة في اجتماع الفيدرالي القادم، مما قد يؤثر على أسواق العملات الرقمية',
      source: 'Reuters',
      timestamp: new Date(Date.now() - 45 * 60000),
      impact: 'negative',
      confidence: 78,
      tags: ['Fed', 'Interest Rates', 'Macro'],
      url: '#',
      sentiment: -0.6
    },
    {
      id: '3',
      title: 'Ethereum يتجه نحو ترقية أمنية جديدة في الربع الأول',
      summary: 'يعمل فريق إيثيريوم على تطوير ترقية أمنية هامة ستحسن من قابلية التوسع وتقلل رسوم المعاملات',
      source: 'CoinDesk',
      timestamp: new Date(Date.now() - 2 * 60 * 60000),
      impact: 'positive',
      confidence: 85,
      tags: ['Ethereum', 'Upgrade', 'Technology'],
      url: '#',
      sentiment: 0.7
    },
    {
      id: '4',
      title: 'تحذيرات من مخاطر التقلبات العالية في الأسواق',
      summary: 'يحذر محللون ماليون من زيادة التقلبات في الأسواق في الأسابيع القادمة بسبب عوامل اقتصادية عالمية',
      source: 'Financial Times',
      timestamp: new Date(Date.now() - 4 * 60 * 60000),
      impact: 'negative',
      confidence: 72,
      tags: ['Market', 'Volatility', 'Risk'],
      url: '#',
      sentiment: -0.5
    }
  ]);

  const [sentiment, setSentiment] = useState<MarketSentiment>({
    overall: 65,
    fear_greed: 72,
    social: 58,
    news: 68,
    trend: 'bullish'
  });

  const [selectedFilter, setSelectedFilter] = useState<'all' | 'positive' | 'negative' | 'neutral'>('all');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    // Simulate real-time sentiment updates
    const interval = setInterval(() => {
      setSentiment(prev => ({
        ...prev,
        overall: Math.max(0, Math.min(100, prev.overall + (Math.random() - 0.5) * 5)),
        fear_greed: Math.max(0, Math.min(100, prev.fear_greed + (Math.random() - 0.5) * 8)),
        social: Math.max(0, Math.min(100, prev.social + (Math.random() - 0.5) * 10)),
        news: Math.max(0, Math.min(100, prev.news + (Math.random() - 0.5) * 6))
      }));
    }, 15000);

    return () => clearInterval(interval);
  }, []);

  const filteredNews = news.filter(item => {
    const matchesFilter = selectedFilter === 'all' || item.impact === selectedFilter;
    const matchesSearch = searchTerm === '' || 
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.summary.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesFilter && matchesSearch;
  });

  const getSentimentColor = (value: number) => {
    if (value >= 70) return 'text-green-400';
    if (value >= 50) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getSentimentBg = (value: number) => {
    if (value >= 70) return 'bg-green-400';
    if (value >= 50) return 'bg-yellow-400';
    return 'bg-red-400';
  };

  const getImpactIcon = (impact: string) => {
    switch (impact) {
      case 'positive': return <TrendingUp className="h-4 w-4 text-green-400" />;
      case 'negative': return <TrendingDown className="h-4 w-4 text-red-400" />;
      default: return <Target className="h-4 w-4 text-gray-400" />;
    }
  };

  const getImpactLabel = (impact: string) => {
    switch (impact) {
      case 'positive': return 'إيجابي';
      case 'negative': return 'سلبي';
      default: return 'محايد';
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'positive': return 'bg-green-600/20 text-green-400 border-green-600/30';
      case 'negative': return 'bg-red-600/20 text-red-400 border-red-600/30';
      default: return 'bg-gray-600/20 text-gray-400 border-gray-600/30';
    }
  };

  return (
    <div className="space-y-6">
      {/* Market Sentiment Dashboard */}
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
          <Target className="h-6 w-6 ml-3 text-purple-400" />
          مؤشر مشاعر السوق
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {/* Overall Sentiment */}
          <div className="text-center">
            <div className="relative w-24 h-24 mx-auto mb-4">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="48"
                  cy="48"
                  r="40"
                  stroke="#374151"
                  strokeWidth="8"
                  fill="none"
                />
                <circle
                  cx="48"
                  cy="48"
                  r="40"
                  stroke={sentiment.overall >= 70 ? '#10b981' : sentiment.overall >= 50 ? '#f59e0b' : '#ef4444'}
                  strokeWidth="8"
                  fill="none"
                  strokeDasharray={`${2 * Math.PI * 40}`}
                  strokeDashoffset={`${2 * Math.PI * 40 * (1 - sentiment.overall / 100)}`}
                  className="transition-all duration-1000"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className={`text-lg font-bold ${getSentimentColor(sentiment.overall)}`}>
                  {sentiment.overall.toFixed(0)}
                </span>
              </div>
            </div>
            <div className="text-white font-medium">عام</div>
            <div className={`text-sm ${getSentimentColor(sentiment.overall)}`}>
              {sentiment.trend === 'bullish' ? 'صعودي' : sentiment.trend === 'bearish' ? 'هبوطي' : 'جانبي'}
            </div>
          </div>

          {/* Fear & Greed */}
          <div className="text-center">
            <div className="w-full bg-gray-700 rounded-full h-4 mb-4">
              <div 
                className={`h-4 rounded-full transition-all duration-1000 ${getSentimentBg(sentiment.fear_greed)}`}
                style={{ width: `${sentiment.fear_greed}%` }}
              />
            </div>
            <div className="text-white font-medium">الخوف والطمع</div>
            <div className={`text-lg font-bold ${getSentimentColor(sentiment.fear_greed)}`}>
              {sentiment.fear_greed.toFixed(0)}
            </div>
          </div>

          {/* Social Sentiment */}
          <div className="text-center">
            <div className="w-full bg-gray-700 rounded-full h-4 mb-4">
              <div 
                className={`h-4 rounded-full transition-all duration-1000 ${getSentimentBg(sentiment.social)}`}
                style={{ width: `${sentiment.social}%` }}
              />
            </div>
            <div className="text-white font-medium">وسائل التواصل</div>
            <div className={`text-lg font-bold ${getSentimentColor(sentiment.social)}`}>
              {sentiment.social.toFixed(0)}
            </div>
          </div>

          {/* News Sentiment */}
          <div className="text-center">
            <div className="w-full bg-gray-700 rounded-full h-4 mb-4">
              <div 
                className={`h-4 rounded-full transition-all duration-1000 ${getSentimentBg(sentiment.news)}`}
                style={{ width: `${sentiment.news}%` }}
              />
            </div>
            <div className="text-white font-medium">الأخبار</div>
            <div className={`text-lg font-bold ${getSentimentColor(sentiment.news)}`}>
              {sentiment.news.toFixed(0)}
            </div>
          </div>
        </div>
      </div>

      {/* News Section */}
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        {/* News Header */}
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-white flex items-center">
            <Newspaper className="h-5 w-5 ml-2" />
            أخبار السوق والتحليلات
          </h3>
          
          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            {/* Search */}
            <div className="relative">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="بحث..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm w-48"
              />
            </div>
            
            {/* Filter */}
            <select
              value={selectedFilter}
              onChange={(e) => setSelectedFilter(e.target.value as any)}
              className="p-2 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm"
            >
              <option value="all">الكل</option>
              <option value="positive">إيجابي</option>
              <option value="negative">سلبي</option>
              <option value="neutral">محايد</option>
            </select>
            
            <button className="p-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors">
              <RefreshCw className="h-4 w-4 text-gray-400" />
            </button>
          </div>
        </div>

        {/* News List */}
        <div className="space-y-4 max-h-[600px] overflow-y-auto">
          {filteredNews.map((item) => (
            <div key={item.id} className="bg-gray-900/50 rounded-lg p-4 border border-gray-700 hover:border-gray-600 transition-all">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1 ml-4">
                  <div className="flex items-center mb-2">
                    <h4 className="text-white font-medium text-lg leading-tight">{item.title}</h4>
                  </div>
                  
                  <p className="text-gray-300 text-sm leading-relaxed mb-3">{item.summary}</p>
                  
                  {/* Tags */}
                  <div className="flex flex-wrap gap-2 mb-3">
                    {item.tags.map((tag, index) => (
                      <span key={index} className="px-2 py-1 bg-blue-600/20 text-blue-300 text-xs rounded border border-blue-600/30">
                        {tag}
                      </span>
                    ))}
                  </div>
                  
                  {/* Meta Info */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4 rtl:space-x-reverse text-xs text-gray-400">
                      <div className="flex items-center">
                        <Globe className="h-3 w-3 ml-1" />
                        {item.source}
                      </div>
                      <div className="flex items-center">
                        <Clock className="h-3 w-3 ml-1" />
                        {item.timestamp.toLocaleString('ar-SA')}
                      </div>
                      <div className="flex items-center">
                        <Zap className="h-3 w-3 ml-1" />
                        الثقة: {item.confidence}%
                      </div>
                    </div>
                    
                    <button className="flex items-center text-blue-400 hover:text-blue-300 text-xs">
                      <ExternalLink className="h-3 w-3 ml-1" />
                      اقرأ المزيد
                    </button>
                  </div>
                </div>
                
                {/* Impact Indicator */}
                <div className="flex flex-col items-center mr-4">
                  <div className={`px-3 py-1 rounded-full text-xs font-medium border flex items-center ${getImpactColor(item.impact)}`}>
                    {getImpactIcon(item.impact)}
                    <span className="mr-1">{getImpactLabel(item.impact)}</span>
                  </div>
                  
                  {/* Confidence Bar */}
                  <div className="w-16 bg-gray-700 rounded-full h-1 mt-2">
                    <div 
                      className={`h-1 rounded-full ${
                        item.confidence >= 80 ? 'bg-green-400' :
                        item.confidence >= 60 ? 'bg-yellow-400' : 'bg-red-400'
                      }`}
                      style={{ width: `${item.confidence}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default NewsAndSentiment;