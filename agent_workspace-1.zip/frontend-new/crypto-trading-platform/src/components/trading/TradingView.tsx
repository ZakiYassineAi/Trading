import React, { useState, useEffect, useRef } from 'react';
import {
  TrendingUp,
  TrendingDown,
  Activity,
  Volume2,
  Maximize2,
  Settings,
  RefreshCw,
  BarChart3,
  Candlestick,
  LineChart
} from 'lucide-react';

interface TradingViewProps {
  symbol?: string;
  interval?: string;
  height?: number;
}

const TradingView: React.FC<TradingViewProps> = ({
  symbol = 'BTCUSDT',
  interval = '1H',
  height = 500
}) => {
  const chartRef = useRef<HTMLDivElement>(null);
  const [chartType, setChartType] = useState<'candlestick' | 'line' | 'area'>('candlestick');
  const [timeframe, setTimeframe] = useState(interval);
  const [isLoading, setIsLoading] = useState(true);
  const [marketData, setMarketData] = useState({
    price: 67234.56,
    change: 2.34,
    changePercent: 3.45,
    high24h: 68500.00,
    low24h: 65800.00,
    volume24h: '1.2B',
    marketCap: '1.32T'
  });

  // Simulate chart data generation
  const generateOHLCData = (days = 30) => {
    const data = [];
    let basePrice = 65000;
    const now = new Date();
    
    for (let i = days; i >= 0; i--) {
      const date = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
      const open = basePrice + (Math.random() - 0.5) * 2000;
      const high = open + Math.random() * 1500;
      const low = open - Math.random() * 1500;
      const close = open + (Math.random() - 0.5) * 1000;
      const volume = Math.random() * 1000000;
      
      data.push({
        time: date.getTime(),
        open: Math.max(0, open),
        high: Math.max(0, high),
        low: Math.max(0, low),
        close: Math.max(0, close),
        volume
      });
      
      basePrice = close;
    }
    
    return data;
  };

  const [chartData] = useState(generateOHLCData());
  const [indicators, setIndicators] = useState({
    ma20: true,
    ma50: false,
    rsi: false,
    macd: false,
    bb: false
  });

  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    // Simulate real-time price updates
    const priceUpdate = setInterval(() => {
      setMarketData(prev => ({
        ...prev,
        price: prev.price + (Math.random() - 0.5) * 200,
        change: (Math.random() - 0.5) * 10,
        changePercent: (Math.random() - 0.5) * 5
      }));
    }, 5000);

    return () => clearInterval(priceUpdate);
  }, []);

  const timeframes = [
    { label: '1د', value: '1m' },
    { label: '5د', value: '5m' },
    { label: '15د', value: '15m' },
    { label: '1س', value: '1h' },
    { label: '4س', value: '4h' },
    { label: '1ي', value: '1d' },
    { label: '1أ', value: '1w' }
  ];

  const chartTypes = [
    { icon: Candlestick, type: 'candlestick' as const, label: 'شموع' },
    { icon: LineChart, type: 'line' as const, label: 'خط' },
    { icon: BarChart3, type: 'area' as const, label: 'منطقة' }
  ];

  const renderChart = () => {
    if (isLoading) {
      return (
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-400 mb-4 mx-auto"></div>
            <p className="text-gray-400">جاري تحميل الرسم البياني...</p>
          </div>
        </div>
      );
    }

    // Simplified chart visualization
    const maxPrice = Math.max(...chartData.map(d => d.high));
    const minPrice = Math.min(...chartData.map(d => d.low));
    const priceRange = maxPrice - minPrice;

    return (
      <div className="relative h-full">
        {/* Price Grid Lines */}
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(6)].map((_, i) => {
            const price = minPrice + (priceRange * i) / 5;
            const y = ((maxPrice - price) / priceRange) * 100;
            return (
              <div
                key={i}
                className="absolute w-full border-t border-gray-800 flex items-center"
                style={{ top: `${y}%` }}
              >
                <span className="text-xs text-gray-500 bg-gray-900 px-2 py-1 rounded ml-2">
                  ${price.toLocaleString()}
                </span>
              </div>
            );
          })}
        </div>

        {/* Chart Data Visualization */}
        <svg className="w-full h-full" viewBox="0 0 800 400">
          {chartData.map((candle, index) => {
            const x = (index / (chartData.length - 1)) * 780 + 10;
            const bodyTop = ((maxPrice - Math.max(candle.open, candle.close)) / priceRange) * 380;
            const bodyBottom = ((maxPrice - Math.min(candle.open, candle.close)) / priceRange) * 380;
            const wickTop = ((maxPrice - candle.high) / priceRange) * 380;
            const wickBottom = ((maxPrice - candle.low) / priceRange) * 380;
            const isGreen = candle.close >= candle.open;

            if (chartType === 'candlestick') {
              return (
                <g key={index}>
                  {/* Wick */}
                  <line
                    x1={x}
                    y1={wickTop}
                    x2={x}
                    y2={wickBottom}
                    stroke={isGreen ? '#10b981' : '#ef4444'}
                    strokeWidth="1"
                  />
                  {/* Body */}
                  <rect
                    x={x - 2}
                    y={bodyTop}
                    width="4"
                    height={Math.max(1, bodyBottom - bodyTop)}
                    fill={isGreen ? '#10b981' : '#ef4444'}
                  />
                </g>
              );
            } else {
              const y = ((maxPrice - candle.close) / priceRange) * 380;
              return (
                <circle
                  key={index}
                  cx={x}
                  cy={y}
                  r="1.5"
                  fill="#3b82f6"
                />
              );
            }
          })}
          
          {/* Price line for line chart */}
          {chartType !== 'candlestick' && (
            <polyline
              points={chartData
                .map((candle, index) => {
                  const x = (index / (chartData.length - 1)) * 780 + 10;
                  const y = ((maxPrice - candle.close) / priceRange) * 380;
                  return `${x},${y}`;
                })
                .join(' ')}
              fill="none"
              stroke="#3b82f6"
              strokeWidth="2"
            />
          )}
          
          {/* MA20 indicator */}
          {indicators.ma20 && (
            <polyline
              points={chartData
                .slice(19)
                .map((_, index) => {
                  const actualIndex = index + 19;
                  const ma = chartData
                    .slice(actualIndex - 19, actualIndex + 1)
                    .reduce((sum, d) => sum + d.close, 0) / 20;
                  const x = (actualIndex / (chartData.length - 1)) * 780 + 10;
                  const y = ((maxPrice - ma) / priceRange) * 380;
                  return `${x},${y}`;
                })
                .join(' ')}
              fill="none"
              stroke="#f59e0b"
              strokeWidth="1.5"
              opacity="0.8"
            />
          )}
        </svg>

        {/* Volume bars at bottom */}
        <div className="absolute bottom-0 w-full h-16 flex items-end justify-between px-2">
          {chartData.map((candle, index) => {
            const maxVolume = Math.max(...chartData.map(d => d.volume));
            const height = (candle.volume / maxVolume) * 60;
            return (
              <div
                key={index}
                className="bg-gray-600 opacity-50 w-1"
                style={{ height: `${height}px` }}
                title={`الحجم: ${candle.volume.toLocaleString()}`}
              />
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden">
      {/* Chart Header */}
      <div className="p-4 border-b border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            <h3 className="text-xl font-bold text-white">{symbol}</h3>
            <div className="flex items-center">
              <span className="text-2xl font-bold text-white ml-2">
                ${marketData.price.toLocaleString()}
              </span>
              <div className={`flex items-center text-sm ${
                marketData.change >= 0 ? 'text-green-400' : 'text-red-400'
              }`}>
                {marketData.change >= 0 ? (
                  <TrendingUp className="h-4 w-4 ml-1" />
                ) : (
                  <TrendingDown className="h-4 w-4 ml-1" />
                )}
                {Math.abs(marketData.change)} ({Math.abs(marketData.changePercent)}%)
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <button className="p-2 hover:bg-gray-700 rounded transition-colors">
              <RefreshCw className="h-4 w-4 text-gray-400" />
            </button>
            <button className="p-2 hover:bg-gray-700 rounded transition-colors">
              <Settings className="h-4 w-4 text-gray-400" />
            </button>
            <button className="p-2 hover:bg-gray-700 rounded transition-colors">
              <Maximize2 className="h-4 w-4 text-gray-400" />
            </button>
          </div>
        </div>

        {/* Market Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
          <div>
            <span className="text-gray-400">أعلى 24س:</span>
            <span className="text-white ml-2">${marketData.high24h.toLocaleString()}</span>
          </div>
          <div>
            <span className="text-gray-400">أقل 24س:</span>
            <span className="text-white ml-2">${marketData.low24h.toLocaleString()}</span>
          </div>
          <div>
            <span className="text-gray-400">الحجم 24س:</span>
            <span className="text-white ml-2">{marketData.volume24h}</span>
          </div>
          <div>
            <span className="text-gray-400">القيمة السوقية:</span>
            <span className="text-white ml-2">{marketData.marketCap}</span>
          </div>
        </div>
      </div>

      {/* Chart Controls */}
      <div className="p-4 border-b border-gray-700 bg-gray-900/50">
        <div className="flex items-center justify-between">
          {/* Chart Type Selector */}
          <div className="flex space-x-1 rtl:space-x-reverse bg-gray-800 rounded-lg p-1">
            {chartTypes.map(({ icon: Icon, type, label }) => (
              <button
                key={type}
                onClick={() => setChartType(type)}
                className={`p-2 rounded transition-colors ${
                  chartType === type
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-400 hover:text-white hover:bg-gray-700'
                }`}
                title={label}
              >
                <Icon className="h-4 w-4" />
              </button>
            ))}
          </div>

          {/* Timeframe Selector */}
          <div className="flex space-x-1 rtl:space-x-reverse">
            {timeframes.map(({ label, value }) => (
              <button
                key={value}
                onClick={() => setTimeframe(value)}
                className={`px-3 py-1 rounded text-sm transition-colors ${
                  timeframe === value
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-400 hover:text-white hover:bg-gray-700'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {/* Indicators */}
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <span className="text-sm text-gray-400 ml-2">المؤشرات:</span>
            <button
              onClick={() => setIndicators(prev => ({ ...prev, ma20: !prev.ma20 }))}
              className={`px-2 py-1 rounded text-xs transition-colors ${
                indicators.ma20
                  ? 'bg-yellow-600/20 text-yellow-400'
                  : 'bg-gray-700 text-gray-400 hover:text-white'
              }`}
            >
              MA20
            </button>
            <button
              onClick={() => setIndicators(prev => ({ ...prev, rsi: !prev.rsi }))}
              className={`px-2 py-1 rounded text-xs transition-colors ${
                indicators.rsi
                  ? 'bg-purple-600/20 text-purple-400'
                  : 'bg-gray-700 text-gray-400 hover:text-white'
              }`}
            >
              RSI
            </button>
          </div>
        </div>
      </div>

      {/* Chart Area */}
      <div ref={chartRef} style={{ height: `${height}px` }} className="relative">
        {renderChart()}
      </div>
    </div>
  );
};

export default TradingView;