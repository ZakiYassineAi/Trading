import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  TrendingDown,
  Activity,
  DollarSign,
  Eye,
  EyeOff,
  Settings,
  RefreshCw,
  AlertTriangle,
  Clock,
  Zap,
  Target
} from 'lucide-react';

interface TradingDashboardProps {
  isLiveTrading?: boolean;
  onToggleMode?: (isLive: boolean) => void;
}

const TradingDashboard: React.FC<TradingDashboardProps> = ({
  isLiveTrading = false,
  onToggleMode
}) => {
  const [isBalanceVisible, setIsBalanceVisible] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [marketData, setMarketData] = useState({
    btc: { price: 67234.56, change: 2.34, volume: '1.2B' },
    eth: { price: 3456.78, change: -1.12, volume: '890M' },
    bnb: { price: 312.45, change: 0.89, volume: '234M' },
    ada: { price: 0.4567, change: 3.45, volume: '178M' }
  });
  const [aiSignals, setAiSignals] = useState([
    { symbol: 'BTC/USDT', action: 'BUY', confidence: 87, reason: 'تحليل فني إيجابي + اختراق المقاومة' },
    { symbol: 'ETH/USDT', action: 'HOLD', confidence: 65, reason: 'تذبذب جانبي - انتظار إشارة واضحة' },
    { symbol: 'BNB/USDT', action: 'SELL', confidence: 78, reason: 'مؤشرات تشبع شرائي' }
  ]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
      // Simulate price updates
      setMarketData(prev => ({
        btc: { ...prev.btc, price: prev.btc.price + (Math.random() - 0.5) * 100 },
        eth: { ...prev.eth, price: prev.eth.price + (Math.random() - 0.5) * 50 },
        bnb: { ...prev.bnb, price: prev.bnb.price + (Math.random() - 0.5) * 10 },
        ada: { ...prev.ada, price: prev.ada.price + (Math.random() - 0.5) * 0.05 }
      }));
    }, 3000);

    return () => clearInterval(timer);
  }, []);

  const portfolioStats = {
    totalBalance: isLiveTrading ? 25847.92 : 10000.00,
    todayPnL: isLiveTrading ? 1234.56 : 256.78,
    todayPnLPercent: isLiveTrading ? 5.02 : 2.57,
    totalPnL: isLiveTrading ? 5847.92 : 1234.56,
    totalPnLPercent: isLiveTrading ? 29.24 : 12.35,
    activePositions: isLiveTrading ? 7 : 4,
    openOrders: isLiveTrading ? 12 : 8
  };

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-6 rtl:space-x-reverse">
          <h1 className="text-3xl font-bold text-white flex items-center">
            <Activity className="h-8 w-8 ml-3 text-blue-400" />
            لوحة التداول الاحترافية
          </h1>
          <div className="text-sm text-gray-400 flex items-center">
            <Clock className="h-4 w-4 ml-1" />
            {currentTime.toLocaleString('ar-SA', { 
              timeZone: 'Asia/Riyadh',
              hour12: true 
            })}
          </div>
        </div>

        <div className="flex items-center space-x-4 rtl:space-x-reverse">
          {/* Live/Paper Trading Toggle */}
          <div className="flex items-center bg-gray-800 rounded-lg p-1">
            <button
              onClick={() => onToggleMode?.(false)}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                !isLiveTrading
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              🎯 وضع التجربة
            </button>
            <button
              onClick={() => onToggleMode?.(true)}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                isLiveTrading
                  ? 'bg-red-600 text-white shadow-lg'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              ⚡ تداول حقيقي
            </button>
          </div>

          <button className="p-2 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors">
            <RefreshCw className="h-5 w-5 text-gray-400" />
          </button>
          <button className="p-2 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors">
            <Settings className="h-5 w-5 text-gray-400" />
          </button>
        </div>
      </div>

      {/* Trading Mode Indicator */}
      <div className={`p-4 rounded-xl border ${
        isLiveTrading
          ? 'bg-red-900/20 border-red-600/30 text-red-400'
          : 'bg-blue-900/20 border-blue-600/30 text-blue-400'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            {isLiveTrading ? (
              <>
                <Zap className="h-5 w-5 ml-2 animate-pulse" />
                <span className="font-medium">وضع التداول الحقيقي نشط</span>
              </>
            ) : (
              <>
                <Target className="h-5 w-5 ml-2" />
                <span className="font-medium">وضع التجربة - أموال وهمية</span>
              </>
            )}
          </div>
          <div className="text-sm opacity-80">
            {isLiveTrading ? 'جميع الصفقات حقيقية ومربوطة بالبورصات' : 'بيئة آمنة للتعلم والتجربة'}
          </div>
        </div>
      </div>

      {/* Portfolio Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Total Balance */}
        <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <DollarSign className="h-8 w-8 text-green-400 ml-2" />
              <span className="text-gray-400">إجمالي الرصيد</span>
            </div>
            <button
              onClick={() => setIsBalanceVisible(!isBalanceVisible)}
              className="p-1 hover:bg-gray-700 rounded transition-colors"
            >
              {isBalanceVisible ? (
                <Eye className="h-4 w-4 text-gray-400" />
              ) : (
                <EyeOff className="h-4 w-4 text-gray-400" />
              )}
            </button>
          </div>
          <div className="text-3xl font-bold text-white mb-2">
            {isBalanceVisible ? `$${portfolioStats.totalBalance.toLocaleString()}` : '••••••'}
          </div>
          <div className="flex items-center text-sm">
            <TrendingUp className="h-4 w-4 text-green-400 ml-1" />
            <span className="text-green-400">
              +${portfolioStats.totalPnL.toLocaleString()} ({portfolioStats.totalPnLPercent}%)
            </span>
          </div>
        </div>

        {/* Today's P&L */}
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center mb-4">
            <Activity className="h-6 w-6 text-blue-400 ml-2" />
            <span className="text-gray-400">ربح/خسارة اليوم</span>
          </div>
          <div className="text-2xl font-bold text-white mb-2">
            ${portfolioStats.todayPnL.toLocaleString()}
          </div>
          <div className="flex items-center text-sm">
            <TrendingUp className="h-4 w-4 text-green-400 ml-1" />
            <span className="text-green-400">+{portfolioStats.todayPnLPercent}%</span>
          </div>
        </div>

        {/* Active Positions */}
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center mb-4">
            <Target className="h-6 w-6 text-purple-400 ml-2" />
            <span className="text-gray-400">المراكز النشطة</span>
          </div>
          <div className="text-2xl font-bold text-white mb-2">
            {portfolioStats.activePositions}
          </div>
          <div className="text-sm text-gray-400">
            {portfolioStats.openOrders} أوامر معلقة
          </div>
        </div>

        {/* AI Trading Status */}
        <div className="bg-gradient-to-br from-purple-900/30 to-blue-900/30 rounded-xl p-6 border border-purple-600/30">
          <div className="flex items-center mb-4">
            <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse ml-2"></div>
            <span className="text-purple-300">الوكيل الذكي</span>
          </div>
          <div className="text-2xl font-bold text-white mb-2">نشط</div>
          <div className="text-sm text-purple-300">
            3 إشارات جديدة
          </div>
        </div>
      </div>

      {/* Market Overview */}
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <h3 className="text-xl font-bold text-white mb-4 flex items-center">
          <Activity className="h-5 w-5 ml-2" />
          نظرة عامة على السوق
        </h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {Object.entries(marketData).map(([symbol, data]) => (
            <div key={symbol} className="bg-gray-900 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-gray-300 font-medium">
                  {symbol.toUpperCase()}/USDT
                </span>
                <div className={`flex items-center text-sm ${
                  data.change >= 0 ? 'text-green-400' : 'text-red-400'
                }`}>
                  {data.change >= 0 ? (
                    <TrendingUp className="h-3 w-3 ml-1" />
                  ) : (
                    <TrendingDown className="h-3 w-3 ml-1" />
                  )}
                  {Math.abs(data.change)}%
                </div>
              </div>
              <div className="text-lg font-bold text-white mb-1">
                ${data.price.toLocaleString()}
              </div>
              <div className="text-xs text-gray-400">
                الحجم: {data.volume}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* AI Trading Signals */}
      <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-6 border border-gray-700">
        <h3 className="text-xl font-bold text-white mb-4 flex items-center">
          <Zap className="h-5 w-5 ml-2 text-yellow-400" />
          إشارات الوكيل الذكي
        </h3>
        <div className="space-y-4">
          {aiSignals.map((signal, index) => (
            <div key={index} className="bg-gray-900/50 rounded-lg p-4 border border-gray-700">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  <span className="font-medium text-white ml-3">{signal.symbol}</span>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    signal.action === 'BUY'
                      ? 'bg-green-600/20 text-green-400 border border-green-600/30'
                      : signal.action === 'SELL'
                      ? 'bg-red-600/20 text-red-400 border border-red-600/30'
                      : 'bg-yellow-600/20 text-yellow-400 border border-yellow-600/30'
                  }`}>
                    {signal.action === 'BUY' ? 'شراء' : signal.action === 'SELL' ? 'بيع' : 'انتظار'}
                  </span>
                </div>
                <div className="flex items-center">
                  <span className="text-sm text-gray-400 ml-2">الثقة:</span>
                  <div className="flex items-center">
                    <div className="w-16 h-2 bg-gray-700 rounded-full overflow-hidden ml-2">
                      <div 
                        className={`h-full rounded-full ${
                          signal.confidence >= 80 ? 'bg-green-400' :
                          signal.confidence >= 60 ? 'bg-yellow-400' : 'bg-red-400'
                        }`}
                        style={{ width: `${signal.confidence}%` }}
                      ></div>
                    </div>
                    <span className="text-sm font-medium text-white">{signal.confidence}%</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-400 text-sm">{signal.reason}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="flex space-x-4 rtl:space-x-reverse">
        <button className="flex-1 bg-green-600 hover:bg-green-700 text-white py-3 px-6 rounded-lg font-medium transition-colors flex items-center justify-center">
          <TrendingUp className="h-5 w-5 ml-2" />
          فتح مركز شراء
        </button>
        <button className="flex-1 bg-red-600 hover:bg-red-700 text-white py-3 px-6 rounded-lg font-medium transition-colors flex items-center justify-center">
          <TrendingDown className="h-5 w-5 ml-2" />
          فتح مركز بيع
        </button>
        <button className="flex-1 bg-purple-600 hover:bg-purple-700 text-white py-3 px-6 rounded-lg font-medium transition-colors flex items-center justify-center">
          <Zap className="h-5 w-5 ml-2" />
          تفعيل التداول الآلي
        </button>
      </div>
    </div>
  );
};

export default TradingDashboard;